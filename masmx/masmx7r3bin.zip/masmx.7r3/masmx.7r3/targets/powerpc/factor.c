extern int soso(int *there);

extern int	 clanjamfrie;

int		 factor = 88;

static int	*acu = &factor;

int	adjustment()
{
   return 33;
}

int overcoat()
{
   soso(acu);
}

