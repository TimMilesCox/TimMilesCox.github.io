long long samantha = 207;
