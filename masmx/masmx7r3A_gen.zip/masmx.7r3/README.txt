
	to update and test the product

	cd src

	read the README.txt in there

