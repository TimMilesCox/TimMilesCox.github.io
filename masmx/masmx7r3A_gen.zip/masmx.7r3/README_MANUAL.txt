

	to maintain the manual

	text-edit manual.txt then copy it

	$ vi manual.txt
	$ cp manual.txt masmx.3r1/doc/masmx.html




