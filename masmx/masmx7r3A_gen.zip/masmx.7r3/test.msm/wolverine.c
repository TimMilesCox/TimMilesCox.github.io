static int jomp();

static int jimp()
{
   return 1;
}

void wolverine()
{
   adjustment();
   soso();
   overcoat();
   tractor();
   jimp();
   jomp();
}

static int jomp()
{
   return 3;
}

