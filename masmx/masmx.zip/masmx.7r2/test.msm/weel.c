double		weel = 1.8e400;
long double weel_weel = 1.8e400;

