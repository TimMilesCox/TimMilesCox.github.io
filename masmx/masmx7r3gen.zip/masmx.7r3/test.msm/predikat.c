long long	atishoo = 0xaaffbbffccffeeff ;
long		drivepenny = 0xaa55cc66 ;
int		farthingwheel = 0xee44aa22 ;

char		prencingbury[] = "Italiana si prego" ;
char		gooseberry[] = { 99, 100, 101 } ;

short		oncehalf[] = { 0xeeee, 0xcccc} ;

float		onemeringue = 2.56e30;
double		catamaran = 1.75e90;
long double	trimaran = 1.5e400;

