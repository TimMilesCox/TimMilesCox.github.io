int     unique_two;
static int      nine = 9;

static int subroutine()
{
   return nine;
}

int second()
{
   return subroutine();
}

