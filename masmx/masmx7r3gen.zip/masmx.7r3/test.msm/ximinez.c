int	unique_one;
static int	nine = 9;

static int subroutine()
{
   return nine;
}

int first()
{
   return subroutine();
}
