#define YIELD asm("trap #0");
