RTA1
====

RTA1 is a freeware processor architecture intended for the embedded and realtime workplace. RTA1 has run in emulation on a Unix host since early 2012 and executes a number of network applications 
