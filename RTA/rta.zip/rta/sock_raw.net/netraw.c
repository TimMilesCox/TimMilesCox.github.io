
#include <stdio.h>

#ifdef	DOS
#include <winsock2.h>
#define detail_code WSAGetLastError()
#define EAGAIN WSAEWOULDBLOCK
#define EWOULDBLOCK WSAEWOULDBLOCK
#else
#include <sys/socket.h>
#include <netinet/in.h>
#define	detail_code errno
#endif
#include <errno.h>

#include "../include.rta/argue.h"

#define	DATA 16384

#if	defined(LINUX)
static struct sockaddr_in	 here = {     AF_INET, 0, 0x07071dac} ;
static struct sockaddr_in	there = {     AF_INET, 0 } ;
#elif	defined(OSX)
static struct sockaddr_in	 here = { 16, AF_INET, 0, 0x07071dac} ;
static struct sockaddr_in	there = { 16, AF_INET, 0 } ;
#elif	defined(DOS)
static struct sockaddr_in        here = {     AF_INET, 0, 0x07071dac} ;
static struct sockaddr_in	there = {     AF_INET, 0 } ;
static WSADATA			 wnet;
#else
static struct sockaddr_in	 here,
				there;;
#error	-DLINUX or -DOSX or /DDOS
#endif

static int                       sixteen = 16;

int main(int argc, char *argv[])
{
   #ifdef DOS
   int		 wsa = WSAStartup(MAKEWORD(1, 1), &wnet);
   #endif

   int		 s = socket(AF_INET, SOCK_RAW, IPPROTO_IP);
   int		 x = bind(s, (struct sockaddr *) &here, 16);
   int		 y;

   unsigned char data[DATA];
   unsigned char *p = (unsigned char *) &here.sin_addr.s_addr;
   unsigned char *q = "172.29.7.12";


   argue(argc, argv);
   if (arguments) q = argument[0];

   sscanf(q, "%hhd.%hhd.%hhd.%hhd", p, p + 1, p + 2, p + 3);

   if (flag['v'-'a'])
   {
      p = (unsigned char *) &here;
      putchar('[');
      for (y = 0; y < 16; y++) printf("%2.2x", *p++);
      printf("]\n");
   }

   #ifdef DOS
   printf("wsa %d\n", wsa);

   if (wsa)
   {
      printf("wsa status %d\n", WSAGetLastError());
      return 0;
   }
   #endif

   printf("s %d b %d\n", s, x);

   if (s < 0)
   {
      printf("socket status %d\n", detail_code);
      return 0;
   }

   if (x < 0)
   {
      printf("bind status %d\n", detail_code);
      #ifdef DOS
      closesocket(s);
      #else
      close(s);
      #endif
      return 0;
   }


   for (;;)
   {
      #if 0
      y = recv(s, data, DATA-1, 0);
      #else
      y = recvfrom(s, data, DATA-1, 0, (struct sockaddr *) &there, &sixteen);
      #endif

      if (y < 0) break;

      for (x = 0; x < y; x++)
      {
          if (x % 20 == 0) putchar('\n');
          printf("%2.2x", data[x]);
      }
   }

   if (y < 0) printf("receive status %d\n", detail_code);

   #ifdef DOS
   closesocket(s);
   #else
   close(s);
   #endif

   return 0;
}


