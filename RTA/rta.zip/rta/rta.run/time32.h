
typedef struct { unsigned	high,
				 low; } step_second32;

extern void start_second(void *);
extern void store_second(void *);

