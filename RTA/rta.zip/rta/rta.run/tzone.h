extern void tzone(struct timeval *xronos);

