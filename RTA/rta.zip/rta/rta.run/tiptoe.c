/*********************************************************************

    Copyright Tim Cox, 2012
    TimMilesCox@gmx.ch

    This file is the instruction-executor of the software-emulation
    of the freeware processor architecture

                RTA1

    RTA1 is a free processor architecture design.

    The executable emulation of RTA1 is free software.

    Instruction code for the target RTA1 architecture is free software
    if it is delivered with this software

    Software programs delivered with this software to connect the
    emulated RTA1 with real network interfaces in the emulator host
    are free software

    Scripts and programs delivered with this software for running
    on other computers and interacting with the RTA1 are free software

    Scripts and utility programs for constructing RTA1 target
    executable software are free software

    You can redistribute it and/or modify RTA1
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    RTA1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with RTA1.  If not, see <http://www.gnu.org/licenses/>.

**********************************************************************/



#define	ASYNC

#ifdef	X86_MSW

#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <memory.h>
#include <fcntl.h>
//	#include <signal.h>
//	#include <sys/time.h>
#include <errno.h>

#ifdef  ASYNC
#include <process.h>
#endif

#else	X86_MSW

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <memory.h>
#include <sys/fcntl.h>
#include <signal.h>
#include <sys/time.h>
#include <errno.h>

#ifdef	ASYNC
#include <pthread.h>
#endif

#endif	X86_MSW

#include "../engine.rta/emulate.h"
#include "../engine.rta/ii.h"
#include "../engine.fs/device24.h"
#include "idisplay.h"
#include "settings.h"
#include "../include.rta/argue.h"
#include "stepping.h"
#include "time32.h"
#include "tzone.h"

int			 indication;

extern int		 iselect;
extern word		*apc;
extern page		*b0p;
extern unsigned int	 psr;
extern unsigned int	_register[];
extern unsigned int	 base[];
extern system_memory	 memory;
extern device		 devices[];

word			*breakpoint;

static int		 runout;

extern void		 execute(word instruction);
extern word		 memory_read(int ea);
extern void		 netbank();
extern void              assign_interface_relay(int device_id, char *text);

static void              assign_array(int device_id, char *text);
static void		 statement();
extern			 void print_register_row(int index);
extern void		 action(char *request);
void			 load_fs(int device_id, char *path);

#ifdef METRIC
unsigned int             delta,
                         metric;

unsigned long long	 delta_base,
                         total_delta,
                         total_metric;

static void              accumulate_metric();
#endif

static step_second32	 step_second;
static int		 interval_seconds_mask;
static unsigned		 clockr[2];

struct timeval		 xronos;

#ifdef ASYNC

static void *async()
{
   char			 request[372];
   char			*_p;

   #ifdef X86_MSW
   #else
   funlockfile(stdin);
   #endif

   if (flag['s'-'a'] == 0)
   {
      putchar(':');
      fflush(stdout);
   }

   for (;;)
   {
      if (flag['s'-'a'])
      {
         putchar('>');
         fflush(stdout);
      }

      request[0] = 0;
      _p = fgets(request, 360, stdin);

      if      (_p)
      {
         if (*_p == '.')
         {
            runout = -1;
            indication &= -1 ^ LOCKSTEP;
         }
         else action(_p);
      }
      else if (request[0]) action(request);
      else printf("please key console input again\n");

      if (flag['v'-'a'])
      printf("[%x %p %x %x]\n", flag['s'-'a'], _p, runout, indication);
   }
}

#endif

static int msw2i(msw w)
{
   return (w.t1 << 16) | (w.t2 << 8) | w.t3;
}

static void statement()
{
   int			 index = iselect;
   int			 index2;

   instruction_display(apc - 1, 1, flag['l'-'a']);
   printf("%6.6x %8.8x\n", psr, apc - memory.p4k[0].w);
   instruction_display(apc, 6, flag['l'-'a']);

   while (index < (iselect | 24))
   {
      print_register_row(index);
      putchar('\n');
      index += 8;
   }

   index = sp;
   printf("[%6.6x]->", index);

   index2 = 7;

   while (index2--)
   {
      if (index > 255) break;
      printf(" %6.6x", _register[index++]);
   }

   printf("\n   ");

   index2 = 8;

   while (index2--)
   {
      if (index > 255) break;
      printf(" %6.6x", _register[index++]);
   }

   printf("\n   ");

   index2 = 8;

   while (index2--)
   {
      if (index > 255) break;
      printf(" %6.6x", _register[index++]);
   }
   putchar('\n');
}

int main(int argc, char *argv[])
{
   #ifdef DAYCLOCK

   #ifdef X86_MSW
   SYSTEMTIME		 stime;
   FILETIME		 ftime;
   #else
//   struct timeval	 time;
   #endif

   int			 instructions = INTERVAL;
   int			 imask;
   #endif


   int			 _x;
   unsigned char	*_p;

   int			 fields,
			 device_id;

   #ifdef LP_TSLICE_HERE
   /* It's not. It's in engine.rta/rta.c:execute() */
   int			 icount;
   #endif

//   char			 command[84];
   unsigned char		 text[72];

   int			 index = 1;
   int			 offset;
   int			 symbol;
   char			*file;

   int			 f, count, image_size = 0;

   word			*load_address = memory.p4k[0].w;
   word			 data_word = { 0, 0, 0, 0 } ;

   #ifdef METRIC
   struct timeval        time2;
   #endif

   #ifdef ASYNC

   #ifdef X86_MSW
   #else

   pthread_attr_t	 asyncb;
   pthread_t		 asyncid;

   #endif
   #endif


   argue(argc, argv);
   printf("RTA1 " RADIX " emulation stepping " STEPPING "\n");

   if (arguments)
   {
      #ifdef X86_MSW
      f = open(argument[0], O_RDONLY | O_BINARY, 0444);
      #else
      f = open(argument[0], O_RDONLY, 0444);
      #endif

      if (f < 0)
      {
         printf("rom image file not available\n");
         return 0;
      }

      if (flag['v'-'a'])
      {
         printf("reading %s with options:\n", argument[0]);
         if (flag['s'-'a']) printf("-s\tsingle step\n");
         if (flag['v'-'a']) printf("-v\tvocal\n");
         if (flag['l'-'a']) printf("-l\tline per instruction\n");
      }

      for (;;)
      {
         count = read(f, (void *) &data_word.t1, 3);
         if (count < 1) break;
         if (count ^ 3) printf("last load word incomplete\n");
         *load_address++ = data_word;
         image_size++;
      }

      printf("rom image %d target words read\n", image_size);
      image_size += 4095;
      base[124] = image_size >> 12;		/*	ROM boundary port	*/
      base[128] = (PAGES_IN_MEMORY - 1) | SYSMEM_FLAG;
						/*	system memory size port	*/

      close(f);
   }
   else
   {
      printf("rom image file required\n");
      return 0;
   }

   netbank();

   if (arguments > 1) load_fs(1, argument[1]);

   for (_x = 2; _x < arguments; _x++)
   {
      _p = argument[_x];

      fields = sscanf(_p, "/%d/%s", &device_id, text);

      if      (fields < 2)    printf("argument %d skipped: requires /device number/device info\n", _x);
      else if (device_id < 3) printf("argument %d skipped: devices 0..2 are fixed\n", _x);
      else
      {
         if      (text[0] == '+') assign_array(device_id, text);
         else if (text[0] == '#') assign_interface_relay(device_id, text);
         else load_fs(device_id, text);
      }
   }

   #ifdef ASYNC

   #ifdef X86_MSW

   _x = _beginthread(async, 0, NULL);
   if (_x < 0) printf("async thread start %d %d\n", _x, errno);
   else        printf("async thread ID %x\n", _x);

   #else

   _x = pthread_attr_init(&asyncb);

   if (_x < 0) printf("threadcbinit %d e %d\n", _x, errno);
   else
   {
      _x = pthread_create(&asyncid, &asyncb, &async, NULL);
      if (_x < 0) printf("async thread start %d %d\n", _x, errno);
      else        printf("async thread ID %p\n", asyncid);
   }

   #endif
   #endif

   printf("key %s\n\n", (flag['s'-'a'])
                        ? "g[break:point] to run"
                        : "s to enter single step");

   #ifdef METRIC
   gettimeofday(&time2, NULL);
   delta_base = time2.tv_sec * 1000000 + time2.tv_usec;
   #endif

   if (uflag['Z'-'A'] == 0) start_second(&step_second);

   for (;;)
   {
      if (runout < 0) break;

      execute(*apc++);

      #ifdef METRIC
      metric++;
      #endif

      #ifdef DAYCLOCK

      instructions--;
      if (!instructions)
      {
         instructions = INTERVAL;

         #if X86_MSW

         GetLocalTime(&stime);
         SystemTimeToFileTime(&stime, &ftime);
         time_pointer = ftime.dwLowDateTime;
         #else

         gettimeofday(&xronos, NULL);

         #endif


         /*****************************************************
            for 32-bit execution with unchanged library
            on platforms the same age as this emulator or newer

            it's not known if tv_sec will really wrap for ever
            because systems may be set to do diagnostics instead

            but if tv_sec does keep wrapping:

            this tweak casts tv_sec to unsigned and prepends
            32 more bits which are all zeros until year 2110 approx.

            the 64-bit seconds-from-1970 count is store on file
            every 70 years when tv_sec high-order bit flips.

            on unsigned overflow every 140 years
            the 32-bit prepend is incremented

            The 2 words on file are read every emulator startup
            and written once per 70 years
         *****************************************************/

         if (uflag['Z'-'A'] == 0)
         {
            if ((xronos.tv_sec & 0x80000000) ^ (step_second.low & 0x80000000))
            {
               /**************************************************
                  ms bit of tv_sec has changed
                  change is 1 to 0 approximately every 140 years
                  and must carry into the high number half
               ***************************************************/

               if (step_second.low & 0x80000000) step_second.high++;
               step_second.low = (unsigned) xronos.tv_sec;
               store_second(&step_second);
            }
         }

         clockr[1] = (unsigned) xronos.tv_usec / 1000
                   + (xronos.tv_sec & 0xFFFF)  * 1000;

         clockr[0] = ((unsigned) xronos.tv_sec >> 16) * 1000
                   + ((step_second.high * 1000) << 16)
                   + (clockr[1] >> 16);

         _register[DAYCLOCK]   =  (clockr[1] & 0xFFFF)
                               | ((clockr[0] & 255) << 16);

         _register[DAYCLOCK_U] = (clockr[0] >>= 8) & 0x00FFFFFF;

         /************************************************
		atomicity writing the two dayclock words
		is not necessary in this model
		because instructions don't happen
		while this does
         ************************************************/

         /****************************************************************
            no need for time zone update more often than 2 second interval
            it might do some GPS I/O
         *****************************************************************/

         if ((xronos.tv_sec ^ interval_seconds_mask) & 0xFFFFFFFE) tzone();
         interval_seconds_mask = xronos.tv_sec;
      }
      #endif

      if (indication & LOCKSTEP) flag['s'-'a'] = 1;

      if (indication & BREAKPOINT)
      {
         if (apc == breakpoint)
         {
            flag['s'-'a'] = 1;
         }
      }

      if (flag['s'-'a'])
      {
         indication |= LOCKSTEP;
         statement();
         putchar('>');
         fflush(stdout);
      }

      if (indication & LOCKSTEP)
      {
         #ifdef METRIC
         accumulate_metric();
         #endif
 
         while (indication & LOCKSTEP) usleep(10000);

         #ifdef METRIC
         gettimeofday(&time2, NULL);
         delta_base = time2.tv_sec * 1000000 + time2.tv_usec;
         #endif
      }

      #ifdef LP_TSLICE_HERE
      /* It's not. It's in engine.rta/rta.c:execute() */
      if (psr & 0x00870000)
      {
         /***************************************************
                not during interrupt
                or with interrupt lock
         ***************************************************/
      }
      else
      {
         if (icount = _register[REALTIME_CLOCK] & 0x00FFFFFF)
         {
            icount--;
            _register[REALTIME_CLOCK] = icount;
            if (!icount) ii(YIELD, LP_TSLICE);
         }
      }
      #endif

      if (indication & CHILLDOWN)
      {
         #ifdef METRIC
         accumulate_metric();
         #endif

         indication &= -1 ^ CHILLDOWN;
         usleep(base[103]);

         #ifdef METRIC
         gettimeofday(&time2, NULL);
         delta_base = time2.tv_sec * 1000000 + time2.tv_usec;
         #endif
      }
   }
   return 0;
}

/*************************************************

        carries out sync or async tty commands

*************************************************/


void load_fs(int device_id, char *path)
{
   int		 xx,
		 banks,
		 index = 0;

   char		*loader = (char *) devices[device_id].dev24;

   #ifdef X86_MSW
   int		 f = open(path, O_RDONLY | O_BINARY, 0444);
   #else
   int		 f = open(path, O_RDONLY, 0444);
   #endif

   vpage	 page;

   if (f < 0) printf("file system image %s error %d\n", path, errno);
   else
   {
      printf("loading device %d file system image %s\n", device_id, path);
      xx = read(f, (void *) &page, sizeof(page));

      /**************************************************
	more exactly volume root directory initial page
      **************************************************/

      if (xx ^ sizeof(page))
      {
         printf("volume header read unsuccessful\n");
         return;
      }

      if (flag['v'-'a'])
      {
         printf("[%2.2x%2.2x%2.2x]\n",
                 page.label.ex.rfw.t1,
                 page.label.ex.rfw.t2,
                 page.label.ex.rfw.t3);
      }

      if (page.label.ex.rfw.t1 ^ 'V')
      {
         if (flag['v'-'a'])
         {
            index = 0;
            loader = (char *) &page;

            while (xx--)
            {
               if ((index & 15) == 0) printf("\n%4.4x: ", index);
               printf("%2.2x", *loader++);
               index++;
            }

            putchar('\n');
         }

         return;
      }

      xx = 3 * (page.label.ex.rfw.t3 - VOLUME1_WORDS);
      banks = msw2i(page.label.ex.granules);

      printf("%.*s %d storage banks\n", xx, &page.label.name[0].t1, banks);
      if (banks == 0) return;

      if (loader) free(loader);

      loader = (char *) calloc(banks, sizeof(fsbank));

      if (loader == NULL)
      {
         printf("%d unable to cache file system\n", errno);
         return;
      }

      devices[device_id].dev24 = (fsbank *) loader;
      base[128 + device_id] = FSYS24_FLAG | banks - 1;

      memcpy(loader, (char *) &page, sizeof(page));
      loader += sizeof(page);
      index = DIRECTORY_BLOCK / GRANULE;

      for (;;)
      {
         xx = read(f, loader, 192);
         if (xx < 0) break;
         if (!xx) break;
         index++;
         loader += 192;
      }

      close(f);
      printf("%d granules loaded\n", index);
   }
}

static void assign_array(int device_id, char *text)
{
   int           banks;
   long          words;

   char         *where;

   sscanf(text + 1, "%d", &banks);

   if ((banks < 1) || banks > 65536)
   {
      printf("+storage banks requested must be decimal 1..65536\n");
      return;
   }

   words = banks << 18;
   where = malloc(words << 2);

   if (where)
   {
//      devices[device_id].flags = DEVICE | SYSMEM;
      devices[device_id].pages = (page *) where;
      base[128 + device_id] = SYSMEM_FLAG | ((banks << 6) - 1);
      printf("device %d additional %ld words memory array added\n", device_id, words);
   }
   else
   {
      printf("device %d requested %ld octets are not available\n", device_id, words << 2);
   }
}

#ifdef METRIC
static void accumulate_metric()
{
   /*******************************************************
        this happens at leading edge of emulation sleep
        requested by I/O chilldown indication
   *******************************************************/

   struct timeval        time3;
   unsigned long long    trailing_edge;

   gettimeofday(&time3, NULL);
   trailing_edge = time3.tv_sec * 1000000 + time3.tv_usec;

   delta = trailing_edge -  delta_base;
   total_metric += metric;
   metric = 0;
   total_delta += delta;
}
#endif

