#define	STEPPING "20.02.2023"
#ifdef	__X64
#define	RADIX	"64-bit"
#else
#define	RADIX	"32-bit"
#endif

