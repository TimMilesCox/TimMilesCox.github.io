#define	STEPPING "14.04.2020"
#ifdef	__X64
#define	RADIX	"64-bit"
#else
#define	RADIX	"32-bit"
#endif

