#define	STEPPING "01.12.2021"
#ifdef	__X64
#define	RADIX	"64-bit"
#else
#define	RADIX	"32-bit"
#endif

