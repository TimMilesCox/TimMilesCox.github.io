#define	STEPPING "04.04.2024"
#ifdef	__X64
#define	RADIX	"64-bit"
#else
#define	RADIX	"32-bit"
#endif

