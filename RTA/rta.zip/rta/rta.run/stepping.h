#define	STEPPING "06.06.2019"
#ifdef	__X64
#define	RADIX	"64-bit"
#else
#define	RADIX	"32-bit"
#endif

