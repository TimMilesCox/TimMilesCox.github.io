#include "csample4.h"

	atest	TEST61
	atest	TEST62
	atest	TEST63
	atest	TEST64
	atest	TEST65
	atest	TEST66

	atest	TEST71
	atest	TEST72
	atest	TEST73
	atest	TEST74

	atest	TEST75
	atest	TEST76

	atest	TEST80
	atest	TEST81
	atest	TEST82
	atest	TEST83
	atest	TEST84
