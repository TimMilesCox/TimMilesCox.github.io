#include "csample3.h"
	atest	TEST45
	atest	TEST46
	atest	TEST47
	atest	TEST48
	atest	TEST49
	atest	TEST50

	atest	TEST51
	atest	TEST52
	atest	TEST53
	atest	TEST54
	atest	TEST55
	atest	TEST56
