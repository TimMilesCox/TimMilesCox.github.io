#define	TEST61	centre * multiplier * 400
#define TEST62	-centre * multiplier * 400
#define	TEST63	centre * -multiplier * 400
#define	TEST64	centre * multiplier * -400
#define	TEST65	-centre * multiplier * -400
#define	TEST66	-centre * -multiplier * 400

#define	TEST71	centre * multiplier * 400 / divisor
#define	TEST72	centre * multiplier * 400 / -divisor
#define	TEST73	-centre * multiplier * 400 / divisor
#define	TEST74	centre * -multiplier * 400 / -divisor

#define	TEST75	-703687414637027500 / divisor
#define	TEST76	703687414637027500 / -divisor

#define	TEST80	-281474968322048 / one
#define	TEST81	-562949936644096 / two
#define	TEST82	-1125899873288192 / four
#define	TEST83	-2251799746576384 / eight
#define	TEST84	-4503599493152768 / sixteen
