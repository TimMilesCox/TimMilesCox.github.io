#define	SMP	8
#define	DEVICES	64

typedef struct	{	int			 REGISTER[288];

			word			*APC,
						*APCZ;
			page			*B0P;
			word			 restart_vector;

			int			 INDICATION,
						 LATENT_PARAMETER,
						 ISELECT;

			int			 PSR,
						*register_set,
						 B0_NAME,
						 B0_SCOPE;

			unsigned		 DELTA,
						 _METRIC;

			unsigned long long	 DELTA_BASE,
						 TOTAL_DELTA,
						 TOTAL_METRIC;

			int			 BASE[IO_PORTS]; } smp ;
