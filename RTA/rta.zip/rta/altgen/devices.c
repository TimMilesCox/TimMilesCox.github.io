device                           devices[64] =
        { { DEVICE | SYSMEM,  BANKS_IN_DEVICE,   { &memory } } ,
          { DEVICE | FSYS24,  BANKS_IN_DEVICE,   { NULL    } } ,
          { DEVICE | DATA16,  BANKS_IN_DEVICE16, { NULL    } } } ;

