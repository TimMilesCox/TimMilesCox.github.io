
#define	TEXTL		160
#define	FPONLINE_TEXTL	600

#define	FP_SERVICE	128
#define	I_SERVICE	129
#define	FP_SERVICE_192	130
#define	FPONLINE_SERVICE 131

#define MAXTRY          1200
#define TWARP           2400
#define	RESENDS		10
