
#define	TEXT		160

#define	FP_SERVICE	4608

#define MAXTRY          1200
#define TWARP           2400

