
#define	TEXTL		160

#define	FP_SERVICE	128
#define	I_SERVICE	129
#define	FP_SERVICE_192	130

#define MAXTRY          1200
#define TWARP           2400

