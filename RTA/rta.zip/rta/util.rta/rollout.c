#include <stdio.h>

#ifdef	W32
#include <winsock.h>
#else
#include <sys/socket.h>
#endif

#include <netinet/in.h>
#include <errno.h>

#include "../include.rta/argue.h"

#ifdef	NETWORK_BYTE_ORDER
#define	PORT(X)	X
#else
#define	PORT(X) ((unsigned short) X >> 8) | (X << 8)
#endif

#define RTA_SERVER		7000

#ifdef	LINUX
static struct sockaddr_in	local	= { AF_INET } ;
static struct sockaddr_in	remote	= { AF_INET, PORT(RTA_SERVER) } ;
#endif

#ifdef	OSX
static struct sockaddr_in	local	= { 16, AF_INET } ;
static struct sockaddr_in	remote	= { 16, AF_INET, PORT(RTA_SERVER) } ;
#endif

#ifdef	W32
static WSADATA wsa
static struct sockaddr_in	local	{ AF_INET } ;
static struct sockaddr_in	remote	{ AF_INET, PORT(RTA_SERVER) } ;
#endif

static int			sixteen = 16;

int main(int argc, char *argv[])
{
   int		 s,
		 x;
		 f;


   argue(argc, argv);

   if ((arguments == 0)
   ||  ((arguments < 2) && (uflag['N'-'A'] == 0))
   ||  ((arguments < 3) && (uflag['N'-'A'] == 0) && (flag['d'-'a'] ^ uflag['O'-'A']))
   ||  ((arguments < 4) && (uflag['N'-'A'] == 0) && (flag['d'-'a'] & uflag['O'-'A'])))
   {
      printf("RTA1 system target address required\n"
             "-f without -N outloads files\n"
             "-O without -N outloads online files\n"
             "-d without -N outloads deleted files\n"
             "outload directories named at 2nd 3rd 4th arguments are written with target files -fOd"
             "-N outloads no files\n"
             "-Y removes files and deleted files at target system\n"
             "-Y with -O removes files, deleted files, and online files at target system\n"
   }
   else
   {
      if (uflag['N'-'A'] == 0)
      {
         x = 1;

         if (flag['f'-'a'])
         {
            f = open(argument[x++]);

            if (f < 0)
            {
               printf("flat files save list "
            }
         }
      }

      #ifdef W32
      WSAStartup(0x0101, &wsa);
      #endif

      s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

      if (s < 0) printf("socket %d %d\n", s, errno);
      else
      {
         x = bind(s, (struct sockaddr *) &local, 16);

         if (x < 0) printf("bind %d %d\n", s, errno);
         else
         {
         }

         close(s);
      }
   }

   return 0;
}
