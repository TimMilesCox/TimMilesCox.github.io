extern void instruction_display(word *pc, int howmany, int linefeed, smp *xcore);

