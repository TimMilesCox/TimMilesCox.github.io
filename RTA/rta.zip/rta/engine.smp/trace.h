void trace(int *list1, int *list2, int *list3, smp *xcore);

extern long	 ultra, ultra1, ultra2, ultra3,
		ultra4, ultra5, ultra6, ultra7;

