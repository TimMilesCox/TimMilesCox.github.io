
static int add_bias(int bias, 
                    int addend[], int biased_addend[], smp *xcore)
{
   int		 signs = addend[0],
                 signs_right = biased_addend[0];

   int		*to;
   int		*from;

   int		 scale = signs_right;
   int		 downscale = -71;
   int		 carry = 0;
   int		 mantissa_words = 3;

   if (psr & FLOATING_RESIDUE)
   {
      if (bias > 160) return 0;
      mantissa_words = 6;
      biased_addend[7] = signs_right;
      addend[7] = signs ^ GUARD_BITS;
      downscale = -143;
   }
   else
   {
      biased_addend[4] = signs_right;
      addend[4] = signs ^ GUARD_BITS;
   }

   if (bias) gshiftr(bias, mantissa_words, signs_right, biased_addend);

   to = addend + mantissa_words + 1;
   from = biased_addend + mantissa_words + 1;

//   *to = signs ^ GUARD_BITS;

   trace(NULL, addend, NULL, xcore); 
   trace(biased_addend, NULL, NULL, xcore);
 
   carry = biased_addend[mantissa_words - 1];

   while (to > addend)
   {
      carry += *from;
      carry += *to;
      *to = carry & 0x00FFFFFF;
      carry >>= 24;

      from--;
      to--;
   }

   if ((signs ^ addend[0]) & 0x00800000)
   {
      /*******************************************************
         polarity inverted
	 the add inverted the mantissa
         now invert the characteristic
      *******************************************************/

//      addend[0] ^= 0x00FFFFFF;

      signs ^= 0x00FFFFFF;
      addend[0] = carry = signs;
      if (!carry) carry = 1;

      to = addend + mantissa_words;

      while (to > addend)
      {
         carry += *to;
         *to  = carry & 0x00FFFFFF;
         carry >>= 24;
         carry += signs;
         to--;
      }
   }
ultra6 = carry;
   if ((addend[0] ^ signs) & 1)
   {
      sright(signs, mantissa_words + 1, addend);
      scale = 1;
   }
   else
   {
      while (((addend[1] ^ signs) & 0x800000) == 0)
      {
         sleft(signs, mantissa_words, addend + 1);
         scale--;
         if (scale < downscale) break;
      }
   }

   trace(NULL, NULL, addend, xcore);
 
   addend[0] = signs;
   return scale;
}

