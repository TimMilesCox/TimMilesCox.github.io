#include "emulate.h"
#include "smp.h"
#include "fpu.h"
#include "ii.h"

#define	GUARD_BITS	_register[128+19]

static int ones_add48(int ea, int target[], int direction, smp *xcore)
{
   int		*register_set = xcore->register_set;
   int		 index = target - _register;

   int		 signs,
		 signs_right,
		 signs2;

   int		 scale,
		 characteristic;

   int		 magnitude_characteristic_difference,
		 magnitude_characteristic_left,
		 magnitude_characteristic_right;

   int		 biased_addend[2];

   int		*normalised = target;
   int		*biased = biased_addend;

   long		 mantissa;
   long		 mantissa_right;

   if ((burst_read2(biased_addend, ea, xcore)) < 0) return -LP_ADDRESS;

   signs       = 0x00FFFFFF & (0 - ((__CHARACTERISTIC >> 23) & 1));
   signs_right = 0x00FFFFFF & (0 - ((biased_addend[0] >> 23) & 1));
   signs2 = signs_right;

   magnitude_characteristic_left = (__CHARACTERISTIC ^ signs) >> 8;
   magnitude_characteristic_right = (biased_addend[0] ^ signs_right) >> 8;

   if ((biased_addend[0] ^ signs_right) & 0x0080)
   {
      /********************************************************
	 normalised source-2 = effective nonzero
         else source-1 unchanged. Test normalising bit
      ********************************************************/

      if (((__CHARACTERISTIC ^ signs) & 0x0080) == 0)
      {
         /********************************************************
             source-2 normalised and source-1 not
             write source-2 to source-1 registers
         ********************************************************/

         target[0] = biased_addend[0];
         target[1] = biased_addend[1];
      }
      else
      {
         /*****************************************************
            both inputs normalised
         *****************************************************/

         magnitude_characteristic_difference = magnitude_characteristic_left
            - magnitude_characteristic_right;

         if (magnitude_characteristic_difference < 0)
         {
            normalised = biased_addend;
            biased = target;
            signs2 = signs;
            signs = signs_right;
            magnitude_characteristic_difference =
            0 - magnitude_characteristic_difference;
         }

         characteristic = normalised[0] ^ signs;


         /********************************

	 63    55	       23	
	 _________________________________
	 |signs|    mantissa   |  guard	 |
	 |_____|_______________|_________|

         ********************************/


         if (magnitude_characteristic_difference > 40)
         {
            /*****************************************************
                no overlap of field mantissa++guard
                so result is input of greater unsigned magnitude
            *****************************************************/

            target[0] = normalised[0];
            target[1] = normalised[1];
         }
         else
         {
            mantissa = ((long) signs << 56)
                     | ((long) (normalised[0] & 255) << 48)
	             | ((normalised[1] & 0x00FFFFFF) << 24)
                     | (signs ^ GUARD_BITS);

            mantissa_right = ((long) signs2 << 56)
                     | ((long) (biased[0] & 255) << 48) 
                     | ((long) (biased[1] & 0x00FFFFFF) << 24)
                     | signs2;

            if (direction) mantissa_right ^= 0xFFFFFFFFFFFF;

            /*****************************************************
               algebraic shift here. (long) is cast to  signed
               declaration is unsigned as this object mostly needs
            *****************************************************/

            (long) mantissa_right >>= magnitude_characteristic_difference;

            mantissa += mantissa_right;

            /*****************************************************
               carry / borrow is shown with change in signs bit 56
               -> shift -> exponent update
            *****************************************************/

            scale = (signs ^ (mantissa >> 56) & 1);

            if (scale)
            {
                /*******************************************************
                  scale is 1
                  a non-sign has carried from mantissa bit 31
                  shift right, characteristic+
                 *******************************************************/

                 mantissa >>= 1;
            }
            else
            {
               /*********************************************************
                  scale is zero and might get less
               *********************************************************/

               while ((((mantissa >> 55) ^ signs) & 1) == 0)
               {
                  /****************************************************
                     mantissa bit 31 has become a sign bit
                     shift left, characteristic-
                  ****************************************************/

                  mantissa <<= 1;
                  scale--;
                  if (scale < -31) break;
               }
            }

            characteristic += scale;

            if (characteristic & 0xFFFF8000)
            {
               /***************************************************
                  exponent overflow or underflow
                  indicate for application
                  and take other default ISR action
               ***************************************************/

               ii(II_XPO, index, xcore);
               return -3;
            }

            if (((mantissa >> 55) ^ signs) & 1)
            {
               /***************************************************
                  normalised
               ***************************************************/
            }
            else characteristic = 0;

            characteristic ^= signs;

            target[0] = ((characteristic & 65535) << 8)
                      | ((mantissa >> 48) & 255);

            target[1] = (mantissa >> 24) & 0x00FFFFFF;
         }
      }
   }
   return 0;
}


int __fa48(int ea, int target[], smp *xcore)
{
   return ones_add48(ea, target, 0, xcore);
}

int __fan48(int ea, int target[], smp *xcore)
{
   return ones_add48(ea, target,  0x00FFFFFF, xcore);
}

int __fm48(int ea, int target[], smp *xcore)
{
   int		*register_set = xcore->register_set;
   int		 index = target - _register;

   int		 signs; 
   int		 signs_right;

   int		 pass = 32;
   int		 characteristic = 0;
   int		 carry;

   int		 magnitude_characteristic_multiplicand,
		 magnitude_characteristic_multiplier;

   int		 multiplier[2];

   unsigned long mantissa;
   unsigned long mantissa_right;
   unsigned long product = 0;

   if ((burst_read2(multiplier, ea, xcore)) < 0) return -LP_ADDRESS;

   signs       = 0x00FFFFFF & (0 - ((target[0] >> 23) & 1));
   signs_right = 0x00FFFFFF & (0 - ((multiplier[0] >> 23) & 1));

   magnitude_characteristic_multiplicand = (target[0] ^ signs) >> 8;
   magnitude_characteristic_multiplier = ((multiplier[0]) ^ signs_right) >> 8;

   mantissa = ((target[1] ^ signs)
            | (long) ((target[0] ^ signs) << 24)) << 32;

   mantissa_right = ((multiplier[1] ^ signs_right)
                  | (long) ((multiplier[0] ^ signs_right) << 24)) << 32;

   if (mantissa & mantissa_right & ((long) 1 << 63))
   {
      /******************************************************
         both normalised or return zero or -zero
      ******************************************************/

      while (pass--)
      {
         mantissa >>= 1;
         if (mantissa_right & ((long) 1 << 63)) product += mantissa;
         mantissa_right <<= 1;
      }

      characteristic = magnitude_characteristic_multiplicand
                     + magnitude_characteristic_multiplier
                     - 0x00004000;

      if ((product & ((long) 1 << 63)) == 0)
      {
         product <<= 1;
         characteristic--;
      }

      if (characteristic & 0xFFFF8000)
      {
         ii(II_XPO, index, xcore);
         return -3;
      }

      product += GUARD_BITS << (32 - 24);
      signs ^= signs_right;
   }

   target[0] = ((characteristic << 8) | (product >> 56)) ^ signs;
   target[1] = ((product >> 32) & 0x00FFFFFF) ^ signs; 
   return 0;
}

int __fd(int ea, int target[], smp *xcore)
{
   int          *register_set = xcore->register_set;
   int           index = target - _register;

   int           signs,
                 signs_right,
                 beats = 32;

   int		 characteristic = 0;

   int		 magnitude_characteristic_dividend,
		 magnitude_characteristic_divisor;

   unsigned long minuend;
   unsigned long subtrahend;
   unsigned long temp;
   unsigned int	 quotient = 0;

   int		 divisor[2];

   if ((burst_read2(divisor, ea, xcore)) < 0) return -LP_ADDRESS;

   signs       = 0x00FFFFFF & (0 - ((target[0] >> 23) & 1));
   signs_right = 0x00FFFFFF & (0 - ((divisor[0] >> 23) & 1));

   minuend = ((target[0] ^ signs) << 24) | (target[1] ^ signs);
   minuend <<= 32;
   minuend |= GUARD_BITS << (32 - 24);

   if (signs) minuend ^= 0xFFFFFFFF00000000;

   /***********************************************************
      positive magnitude minuend ++ guard bits
      minuend and subtrahend start 1 position down
   ***********************************************************/

   minuend >>= 1;

   if (minuend & ((long) 1 << 61))
   {
      /********************************************************
         and if not the result is already computed
      ********************************************************/

      subtrahend = (long) ((divisor[0] << 24) | divisor[1]) << 32;
      if (signs_right == 0) subtrahend ^= 0xFFFFFFFFFFFFFFFF;

      /********************************************************
         add negative magnitude
      ********************************************************/

      while (beats--)
      {
         /*****************************************************
            msbit 63 of temp is carry
            high order bit of both numbers is bit 62 
            subtrahend is negative magnitude
            subtrahend shifts down before each add
            and replaces bit 62 with a 1 
         *****************************************************/

         quotient <<= 1;
/*       minuend >>= 1;	NO. just once 	*/
         subtrahend >>= 1;
         subtrahend |= (long) 1 << 62;
         temp = minuend + subtrahend;

         if (temp & ((long) 1 << 63))
         {
            /*************************************************
               carry
            *************************************************/

            quotient |= 1;
            minuend = temp & 0x7FFFFFFFFFFFFFFF;
         }
      }

      characteristic =  magnitude_characteristic_dividend
                     -  magnitude_characteristic_divisor
                     +  0x4000;
      beats = 32;

      while (beats--)
      {
         if (quotient & 0x80000000) break;
         characteristic--;
         quotient <<= 1;
      }

      if (characteristic & 0xFFFF8000)
      {
         ii(II_XPO, index, xcore);
         return -3;
      }

      signs ^= signs_right;
      
      target[0] = (quotient >> 24) | (characteristic << 8) ^ signs;
      target[1] = (quotient & 0x00FFFFFF) ^ signs;
   }
   return 0;
}

