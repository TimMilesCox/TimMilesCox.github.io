
resolving minor issues

RTA1 emulator for PowerPC 32-bit expected to be available again
30 December 2022

