Unix script sgen

	./sgen		#	for test assembly with summary information
	./sgen	-l	#	for verbose assembly
	./sgen	-w	#	for silent assembly

MS command file sgen.bat

	.\sgen
	.\sgen	-l
	.\sgen	-w

