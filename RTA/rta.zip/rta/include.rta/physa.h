extern unsigned char * physa(unsigned char *name);

