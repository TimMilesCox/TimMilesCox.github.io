#include <stdio.h>
void target(char *s);
void (*p) (char *s);
int main(int argc, char *argv[])
{
   p = target;
   p(argv[1]);
   return 0;
}

void target(char *s)
{
   if (s == NULL) s = "ye might huv gied me soam chiel to crie";
   printf("%s\n", s);
}

