extern __register:near
extern _base:near
extern _apc:near
extern _psr:near
extern _context:near
extern _memory:near
extern _devices:near

HALF_W	equ	128
FP_R	equ	8

r	equ	0
k	equ	1
x	equ	2
y	equ	3
a	equ	4
b	equ	5
mantissa2 equ	6
mantissa3 equ	7
residue	equ	8
p	equ	12
q	equ	13
fp	equ	14
s_p	equ	15

rdatac	equ	20
rdata	equ	21
wdatac	equ	22
wdata	equ	23


fp_guard equ	128+19

rt_clock equ	128+20
priority equ	128+21
dayclock_u equ	128+22
dayclock equ	128+23

R	equ	r*4
K	equ	k*4
X	equ	x*4
Y	equ	y*4
A	equ	a*4
B	equ	b*4
MANTISSA2 equ	mantissa2*4
MANTISSA3 equ	mantissa3*4
RESIDUE	equ	residue*4

P	equ	p*4
Q	equ	q*4
FP	equ	fp*4
S_P	equ	s_p*4

RDATAC	equ	rdatac*4
RDATA	equ	rdata*4
WDATAC	equ	wdatac*4
WDATA	equ	wdata*4

FP_GUARD equ	fp_guard*4

RT_CLOCK equ	rt_clock*4
PRIORITY equ	priority*4
DAYCLOCK_U equ	dayclock_u*4
DAYCLOCK equ	dayclock*4

DEVICE  equ	32768
SYSMEM  equ	16384
DATA16  equ	1
FSYS24  equ	2

extern	_devices:near

