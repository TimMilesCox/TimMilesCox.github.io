#include <stdio.h>
#include "../engine.rta/emulate.h"
extern system_memory memory;
#include "devices.c"

