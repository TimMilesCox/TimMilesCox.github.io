#ifdef	__64BIT__
typedef	long i64;
#else
typedef	long long i64;
#endif
