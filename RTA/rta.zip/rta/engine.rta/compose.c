static void sabr(int v, int ea)
{
   unsigned		 device_descriptor;
   int			 device_index,
			 w;
   word			*_w;

   if ((ea > 1) && (ea < 64))
   {
      if ((v & 0x00400000) && (device_index = v & 63))
      {
         /*********************************************
            yes that is intended to be an assignment

            device array outside system memory
            only interrupt code may base it
            unless it is array memory
            with bus behaviour like system memory
         *********************************************/

         /********************************************
            allowed for interrupt code but check
         ********************************************/

         #ifdef CHECK_ON_BASE
         device_descriptor = base[128 + device_index];
                              
         switch (device_descriptor & 0x00C00000)
         {
            case SYSMEM_FLAG:
               /*************************************
                  applications and ISRs
                  may both base array memory
               *************************************/

               if (((v & 0x003FFFC0) | 63)
               >   (device_descriptor & 0x003FFFFF)) v = 0x00C00001;

               break;

            case DATA16_FLAG:
            case FSYS24_FLAG:

               if (psr & 0x00800000)
               {
                  /**********************************
                     ISRs may base peripheral arrays
                     if the block is in range
                  **********************************/

                  if (((v >> 6) & 65535)
                  >   (base[128 + device_index] & 65535)) v = 0x00C00001;
               }
               else
               {
                  /**********************************
                     whereas applications may not
                     too easy to do inadvertantly
                  **********************************/

                  GUARD_AUTHORITY
                  return;
               }

               break;

            default:
               /**********************************
                  flag value 00 void device
               **********************************/

               v = 0x00C00001;
         }
         #endif		/*	CHECK_ON_BASE	*/
      }

      #ifdef CHECK_ON_BASE
      else if ((v & 0x00BFFFFF) < base[72])
      {
         /***********************************************
            no-one pulls up the restart and ISR pages
            into their operand space
            covers register a accidentally zero
         ***********************************************/

         v = 0x00C00001;
      }
      else if ((v & 0x00BFFFFF) < PAGES_IN_MEMORY)
      {
         /***********************************************
            you're fine
         ***********************************************/
      }
      else
      {
         /***********************************************
            no such block of storage
         ***********************************************/

         v = 0x00C00001;
      }
      #endif

      w = base[65] & 0x0000FFFF;

      _w = &memory.p4k[w].w[BASE_TABLE+ea];

      _w->t3 = v;
      _w->t2 = v >> 8;
      _w->t1 = v >> 16;

      #if 0
      if (v & 0x00800000)
      {
         /************************************************
            implementations with bank index
            translation have that here
         ************************************************/
      }
      #endif

      base[ea] = v;
   }
   else
   {
      /**************************************************
         window tag < 2 or > 63
      **************************************************/

      GUARD_AUTHORITY
   }
}


/*******************************************************************

	uses a language extension to force jump table implementation
	of large switch()

*******************************************************************/

void execute(word instruction)
{
   static void *pointers_0[32] = { &&__sr, &&__sk, &&__sx, &&__sy, &&__sa, &&__sb, &&__z, &&__pop,
                                   &&__lr, &&__lk, &&__lx, &&__ly, &&__la, &&__lb, &&__tz, &&__tp,
                                   &&__ax, &&__ay, &&__or, &&__orB, &&__and, &&__andB, &&__xor, &&__xorB,
                                   &&__aa, &&__ab, &&__ana, &&__anb, &&__m_, &&__mf_, &&__d_, &&__push } ;

   static void *pointers_6[32] = { &&__sar, &&__sbr, &&__dsr, &&__jdr, &&__sal, &&__sbl, &&__dsl, &&__lcal,
                                   &&__rar, &&__rbr, &&__drr, &&__jnc, &&__ral, &&__rbl, &&__drl, &&__jc,
                                   &&__saa, &&__sba, &&__dsa, &&__jao, &&__jpa, &&__jpb, &&__j, &&__jpo,
                                   &&__jza, &&__jzb, &&__jnza, &&__jnzb, &&__jna, &&__jnb, &&__jxge, &&__jyge } ;

   static void *pointers_7[32] = { &&__ts, &&__n, &&__inc, &&__dec, &&__sim, &&__popA, &&__src, &&__slc, 
                                   &&__qs, &&__ql, &&__dte, &&__dpop, &&__fa, &&__fan, &&__fm, &&__fd,
                                   &&__qpop, &&__qpush, &&__ex, &&__dpush, &&__lsc, &&__mta, &&__sc, &&__mlb,
                                   &&__ds, &&__dl, &&__da, &&__dan, &&__dlsc, &&__nop, &&__go, &&__call } ;


   int           icode = instruction.t1;
   int           designator = icode & 7;
   int		 index = icode >> 3;
   int           ea, xtag;

   int          *_p,
                *_q;

   int           v, w, device_index;
   unsigned      device_descriptor;
   int           buffer[4];
   int           signs;
   device       *devicep;

   word         *_w;
   word          x_instruction;

   EFFECTIVE_ADDRESS

   switch (designator)
   {
      case 6:
         goto *pointers_6[index];

         __sar:
               a = (a >> ea) & 0x00FFFFFF;      /* shift A right        */
           return;

         __sbr:
               b = (b >> ea) & 0x00FFFFFF;      /* shift B right        */
           return;

         __dsr:
               gshiftr(ea, 2, 0, &a);           /* double shift right   */
           return;

         __jdr:
               /****************************************************

                        jump decrement R

                        always decrement R
                        jump unless R was zero before the instruction

               *****************************************************/

               v = (r & 0x00FFFFFF) + 0x00FFFFFF;
               r = v & 0x00FFFFFF;
               if (v & 0x01000000) apc = &b0p->w[ea];
           return;

         __sal:
               a = (a << ea) & 0x00FFFFFF;      /* shift A left         */
           return;

         __sbl:
               b = (b << ea) & 0x00FFFFFF;      /* shift B left         */
           return;

         __dsl:
               gshiftl(ea, 2, 0, &a);           /* double shift left    */
           return;

         __lcal:
               /****************************************************

                        local call

                        push the saved program counter
                        = location of following instructiom
                        = absolute program counter minus base B0
                        on the internal stack

                        jump to ea

                ****************************************************/

               STACK(1)
               v--;
               _p = _register + v;
               *_p = apc - b0p->w;
               *_q = v;

               apc = &b0p->w[ea];
           return;



         __rar:
               gshiftr(ea, 1, a, &a);           /* rotate A right       */
           return;

         __rbr:
               gshiftr(ea, 1, b, &b);           /* rotate B right       */
           return;

         __drr:
               buffer[0] = buffer[2] = a;
               buffer[1] = buffer[3] = b;

               gshiftr(ea % 48, 4, 0, buffer);
               a = buffer[2];                   /* double rotate right  */
               b = buffer[3];
           return;

         __jnc:
                                                /*      jump no carry   */
               if ((psr & CARRY) == 0) apc = &b0p->w[ea];
           return;

         __ral:
               gshiftl(ea, 1, a, &a);           /* rotate A left        */
           return;

         __rbl:
               gshiftl(ea, 1, b, &b);           /* rotate B left        */
           return;

         __drl:
               buffer[0] = buffer[2] = a;
               buffer[1] = buffer[3] = b;

               gshiftl(ea % 48, 4, 0, buffer);
               a = buffer[0];                   /* double rotate left   */
               b = buffer[1];
           return;

         __jc:
                                                /* jump carry           */
               if (psr & CARRY) apc = &b0p->w[ea];
           return;



         __saa:
               signs = 0x00FFFFFF & ((a << 8) >> 31);
               gshiftr(ea, 1, signs, &a);
                                                /* shift A algebraic    */
           return;

         __sba:
               signs = 0x00FFFFFF & ((b << 8) >> 31);
               gshiftr(ea, 1, signs, &b);
                                                /* shift B algebraic    */
           return;

         __dsa:
               signs = 0x00FFFFFF & ((a << 8) >> 31);
               gshiftr(ea, 2, signs, &a);
                                        /* double shift algebraic       */
           return;

         __jao:
               if (a & 1) apc = &b0p->w[ea];
           return;

         __jpa:
               /****************************************************

                        jump positive A

                        jump if bit 23 of A is clear

               *****************************************************/


               if (a & 0x00800000)
               {
               }
               else apc = &b0p->w[ea];

           return;

         __jpb:
               /****************************************************

                        jump positive B

                        jump if bit 23 of B is clear

                ****************************************************/


               if (b & 0x00800000)
               {
               }
               else apc = &b0p->w[ea];

           return;

         __j:
               /******************************************************
                        J instruction. Jump intra bank
               *******************************************************/

               apc = &b0p->w[ea];
           return;

         __jpo:
               v = a & k;
               v &= 0x00FFFFFF;
               v ^= v >> 16;
               v ^= v >>  8;
               v ^= v >>  4;
               v ^= v >>  2;
               v ^= v >>  1;

               if (v & 1)  apc = &b0p->w[ea];

           return;



         __jza:
              if (a & 0x00FFFFFF)
               {
               }
               else apc = &b0p->w[ea];
           return;

         __jzb:
               if (b & 0x00FFFFFF)
               {
               }
               else  apc = &b0p->w[ea];
           return;

         __jnza:
               if (a & 0x00FFFFFF) apc = &b0p->w[ea];
           return;

         __jnzb:
               if (b & 0x00FFFFFF) apc = &b0p->w[ea];
           return;

         __jna:
               if (a & 0x00800000) apc = &b0p->w[ea];
           return;

         __jnb:
               if (b & 0x00800000) apc = &b0p->w[ea];
           return;

         __jxge:

               /******************************************************
                        JXGE instruction (jump x not less than r)
               ******************************************************/

               if ((x & 0x00FFFFFF) < (r & 0x00FFFFFF))
               {
               }
               else apc = &b0p->w[ea];

           return;

         __jyge:

               /******************************************************
                        JYGE instruction (jump y not less than r)
               ******************************************************/

               if ((y & 0x00FFFFFF) < (r & 0x00FFFFFF))
               {
               }
               else apc = &b0p->w[ea];

           return;


      case 7:
         goto *pointers_7[index];

         __ts:
               /*************************************************

                        test and set

                        always set bit 23 of the storage
                        operand

                        skip next instruction if that bit
                        was previously clear

                        touch no flags

               *************************************************/


               #ifdef ABSOTS

               /************************************************
                  operand_read() and operand_write()
                  don't look at the designator argument
                  before classing EA in register range
                  so switch ABSO uses * _w = memory_hold(ea)
                  to get a pointer for TS instruction
                  and that is one less call to operand_etc()

                  of course TS target is never in range 0..255
               ************************************************/

               if ((_w = memory_hold(ea)) == NULL) return;

               v = _w->t1;
               v ^= 128;

               if (v & 128)
               {
                  _w->t1 = v;
                  apc++;
               }

               #else

               OPERAND7(v)
               v ^= 0x00800000;

               if (v & 0x00800000)
               {
                  operand_write(v, ea, 7);
                  apc++;
               }

               #endif

           return;

         __n:

               /************************************************

                        negate

                        ones complement invert the storage
                        operand

                        touch no flags

               ************************************************/

               OPERAND7(v)
               v ^= 0x00FFFFFF;
               operand_write(v, ea, 7);

           return;

         __inc:

               /***********************************************

                        increment

                        touch no flags

               ***********************************************/

               OPERAND7(v)
               v++;
               operand_write(v & 0x00FFFFFF, ea, 7);

           return;

         __dec:

               /**************************************************

                        decrement

                        touch no flags

               **************************************************/

               OPERAND7(v)
               v--;
               operand_write(v & 0x00FFFFFF, ea, 7);

           return;

         __sim:

               /**************************************************

                        switch interrupt mask

                        exchange the interrupt mask in PSR 22..16
                        with the value in the storage operand

               **************************************************/

               OPERAND7(v)
               operand_write(((psr >> 16) & 0x7F), ea, 7);
               psr = (psr & 0x0080FFFF) | ((v & 0x7F) << 16);
           return;

         __popA:

               /**************************************************

                        pop and add

                        take a word form the internal stack
                        and add it to the target word

                        25th bit of sum -> carry

                        increment sp after operand read
                        and before operand write

                        *_q -> is the same sp even before and after
                        even if operand read faults

               **************************************************/

               STACK_READ(1)
               _p = _register + v;
               OPERAND7(w)
               w += *_p;

               v++;
               *_q = v;

               psr = (psr & 0x00FFFFFE) | ((w >> 24) & 1);
               operand_write(w & 0x00FFFFFF, ea, 7);

           return;

         __src:

               /*************************************************

                        shift right through carry

                        25-bit rotate one bit position
                        to the right

                        carry moves into high bit of storage operand
                        low bit of the storage operand moves into carry

                        touch no other flags

               *************************************************/

               OPERAND7(v)
               operand_write((v >> 1) | ((psr & CARRY) << 23),
                             ea, 7);
               psr &= CARRY^0x00FFFFFF;
               psr |= v & 1;
           return;

         __slc:

               /*************************************************

                        shift left through carry

                        25-bit rotate one bit position
                        to the left

                        carry moves into low bit of storage operand
                        high bit of the storage operand moves into carry

                        touch no other flags

               *************************************************/

               OPERAND7(v)
               operand_write(0x00FFFFFF & ((v << 1) | (psr & CARRY)), ea, 7);
               psr &= CARRY^0x00FFFFFF;
               psr |= (v & 0x00800000) >> 23;               
           return;



         __qs:

               /*************************************************

                        quadruple store

                        store the four accumulators A:B:6:7

               *************************************************/

               burst_write4(&a, ea);
           return;

         __ql:

               /*************************************************

                        quadruple load

                        load the four accumulators A:B:6:7

               *************************************************/

               burst_read4(&a, ea);
           return;

         __dte:

               /*************************************************

                        double test subtract [ a b ] - operand
                        skip equal

               *************************************************/

               if ((burst_read2(buffer, ea)) < 0) return;

               if ((a ^ buffer[0]) | (b ^ buffer[1]))
               {
               }
               else apc++;

           return;

         __dpop:

               /*************************************************

                        double pop

                        pop two words from the internal
                        stack top

                        decrement sp before burst write
                        in case the popped objects include sp

               *************************************************/

               STACK_READ(2);
               _p = _register + v;
               *_q = v + 2;

               burst_write2(_p, ea);
           return;

         __fa:

               /*************************************************

                        floating add                    fpu.c

                        add the four-word floating-point operand
                        to the floating-point value in the four
                        accumulators A:B:6:7

               *************************************************/

               __fa(ea, &a);

           return;

         __fan:

               /*************************************************

                        floating add negative           fpu.c

                        add the negative (i.e. subtract the value)
                        of the four-word floating-point operand
                        to the floating-point value in the four
                        accumulators A:B:6:7

               *************************************************/

               __fan(ea, &a);

           return;

         __fm:

               /*************************************************

                        floating multiply               fpu.c

                        multiply the floating-point value
                        in the four accumulators A:B:6:7
                        by the four-word floating-point operand

               *************************************************/

               __fm(ea, &a);

           return;

         __fd:

               /*************************************************

                        floating divide                 fpu.c

                        divide the floating-point value
                        in the four accumulators A:B:6:7
                        by the four-word floating-point operand

               *************************************************/

               __fd(ea, &a);

           return;



         __qpop:

               /*************************************************

                        quadruple pop

                        pop four words from the internal
                        stack top

                        decrement sp before burst write
                        in case the popped objects include sp

               *************************************************/


               STACK_READ(4)
               _p = _register + v;
               *_q = v + 4;

               burst_write4(_p, ea);

           return;

         __qpush:

               /*************************************************

                        quadruple push

                        push four words onto the internal
                        stack top

                        acquire operands before decrementing sp
                        in case the pushed objects include sp

                        sp at *_q is the same one before and after
                        even if a fault occurs in burst_read

               *************************************************/

               STACK(4)
               v -= 4;
               _p = _register + v;
               if ((burst_read4(_p, ea)) < 0) return;
               *_q = v;

           return;

         __ex:

               /*************************************************

                        execute

                        read an instruction word from storage
                        and execute it

               *************************************************/

               x_instruction = memory_read(ea);
               execute(x_instruction);

           return;

         __dpush:

               /*************************************************

                        double push

                        push two words onto the internal
                        stack top

                        acquire operands before decrementing sp
                        in case the pushed objects include sp

                        sp at *_q is the same one before and after
                        even if a fault occurs in burst_read

               *************************************************/

               STACK(2)
               v -= 2;
               _p = _register + v;
               if ((burst_read2(_p, ea)) < 0) return;
               *_q = v;

           return;

         __lsc:

               /*************************************************

                        load shift and count            alu.c

                        load accumulator A from storage and shift
                        left until bit 23 is not the sign polarity

                        stop at 24 if all bits = sign

                        shift count in accumulator B

               *************************************************/

               lsc(ea);

           return;

         __mta:

               /*************************************************

                        masked test A                   alu.c

                        test subtract
                        storage operand AND mask _register K
                        from accumulator A AND mask _register K

                        skip next instruction if equal

               *************************************************/


               
               OPERAND7(v)

               if ((a & k) ^ (v & k))
               {
               }
               else apc++;

           return;

         __sc:

               /*************************************************

                        store carry

                        store the value if the CARRY flag
                        as a data word containing zero or one

               *************************************************/

               operand_write(psr & CARRY, ea, 7);

           return;

         __mlb:

               /*************************************************

                        masked load B

                        accumulator B = (B AND (NOT mask _register K))
                        OR (storage operand AND mask _register K)

               **************************************************/

               OPERAND7(v)
               b = ((b & (k ^ 0x00FFFFFF)) | (v & k)) & 0x00FFFFFF;

           return;



         __ds:

               /*************************************************

                        double store

                        store the two accumulators A:B

               *************************************************/

               burst_write2(&a, ea);

           return;

         __dl:
               /*************************************************

                        double load

                        load the two accumulators A:B

               *************************************************/

               burst_read2(&a, ea);

           return;

         __da:

               /*************************************************

                        double add                      alu.c

                        add the two-word integer from storage
                        to accumulators A:B

                        set or clear CARRY

               *************************************************/

               if ((burst_read2(buffer, ea)) < 0) return;

               buffer[1] += b;
               b = buffer[1] & 0x00FFFFFF;
               buffer[0] = buffer[0] + a + ((buffer[1] >> 24) & 1);
               a = buffer[0] & 0x00FFFFFF;
               psr = (psr & 0x00FFFFFE) | ((buffer[0] >> 24) & 1);

           return;

         __dan:

               /*************************************************

                        double add negative             alu.c

                        add the negative (i.e. subtract the value)
                        of two-word integer from storage
                        to accumulators A:B

                        set or clear CARRY

               *************************************************/

               if ((burst_read2(buffer, ea)) < 0) return;

               buffer[1] ^= 0x00FFFFFF;
               buffer[0] ^= 0x00FFFFFF;
               buffer[1] = buffer[1] + b + 1;
               b = buffer[1] & 0x00FFFFFF;
               buffer[0] = buffer[0] + a + ((buffer[1] >> 24) & 1);
               a = buffer[0] & 0x00FFFFFF;
               psr = (psr & 0x00FFFFFE) | ((buffer[0] >> 24) & 1);

           return;

         __dlsc:

               /*************************************************

                        double load shift and count     alu.c

                        load accumulators A:B from storage and shift
                        left until bit 47 is not the sign polarity

                        stop at 48 if all bits = sign

                        shift count in accumulator _register 6

               *************************************************/

               dlsc(ea);

           return;

         __nop:
           return;

         __call:

               /*********************************************************

                        same as GO except offset and bank of following
                        instruction are first placed in the internal
                        stack where far return instruction FRET should
                        find them later

               **********************************************************/

               STACK(2)
               v -= 2;
               _p = _register + v;
               _p[1] = apc - b0p->w;
               _p[0] = b0_name;
               *_q = v;

              /* and fall thru */

         __go:

               /***************************************************

                        switch instruction base B0 according to
                        bits 23..6 of the operand word loaded from
                        storage

                        jump to location 0..63 of the new B0 bank
                        according to bits 6..0 of the operand word

               ***************************************************/

               OPERAND7(b0_name)

               if (b0_name & 0x00800000)
               {
                  /************************************************
                        read the gate
                  ************************************************/

                  if ((burst_read2(buffer, b0_name & 0x007FFFFF)) < 0) return;
                  b0_name = buffer[1];
                  if (buffer[0] & 0x00FC0000) b0_name |= 0x00800000;
                  b0_scope = b0_name & 0x003FFFFF;
                  v = b0_scope;
                  b0_scope += buffer[0] >> 18;
                  w = buffer[0] & 262143; 
               }
               else
               {
                  b0_name &= 0x003FFFFF;        /* bit 22 is reserved */
                  w = b0_name & 63;
                  b0_name >>= 6;
                  v = b0_name;
                  b0_scope = v;
               }

               if (b0_scope > (PAGES_IN_MEMORY - 1))
               {
                  GUARD_INTERRUPT
                  return;
               }

               if  (psr & 0x00800000)
               {
               }
               else if (v < base[72])
               {
                  /*****************************************
                     must be an ISR to jump in there
                  *****************************************/

                  GUARD_AUTHORITY
                  return;
               }

               base[0] = v;
               b0p = &memory.p4k[v];
               apc = &b0p->w[w];

               #ifdef INSTRUCTION_U
               base[INSTRUCTION_U] = b0_scope;
               apcz = &memory.p4k[b0_scope].w[4095];
               #endif

           return;


      default:
         goto *pointers_0[index];

         __sr:
               if (designator == I)
               {
                  /******************************************************

                        INA instruction
                        read IO port to accumulator A

                  *******************************************************/

                  a = 0x00FFFFFF;
                  if (ea < IO_PORTS) a = base[ea];
                  return;
               }
 
               if (designator == XI)
               {
                  /******************************************************

                        ON instruction (or PSR flags)

                  *******************************************************/

                  psr |= ea & 65535;
                  return;
               }

               /*********************************************************

                        SR instruction
                        store repeat _register R

               *********************************************************/

               operand_write(r, ea, designator);

           return;

         __sk:
               if (designator == I)
               {
                  /******************************************************

                        INB instruction
                        read IO port to accumulator B

                  *******************************************************/

                  b = 0x00FFFFFF;
                  if (ea < IO_PORTS) b = base[ea];
                  return;
               }
               
               if (designator == XI)
               {
                  /******************************************************

                        OFF instruction (nor PSR flags)

                  *******************************************************/
               
                  psr &= (ea & 65535) ^ 0x00FFFFFF;
                  return;
               }

               /*********************************************************

                        SK instruction
                        store mask _register K

               *********************************************************/

               operand_write(k, ea, designator);

           return;

         __sx:
               if (designator == I)
               {
                  /******************************************************

                        OUTA instruction
                        write accumulator A to IO port

                  *******************************************************/

                  #if 1
                  oport(ea, a);
                  #else
                  if (ea < IO_PORTS) base[ea] = a;
                  if (ea == 102) indication |= a;
                  #endif

                  return;
               }
               
               if (designator == XI)
               {
                  /******************************************************

                        read staging _register                  sr.c

                        shift bits from staging _register RDATA to
                        accumulator A, decrementing available data bits
                        count in _register RDATAC. Read memory
                        via pointer _register Q and update Q if more
                        data required

                  *******************************************************/
               
                  rsr(ea);
                  return;
               }

               /********************************************************

                        SX instruction
                        store index _register X

               *********************************************************/

               operand_write(x, ea, designator);

           return;

         __sy:
               if (designator == I)
               {
                  /******************************************************

                        OUTB instruction
                        write accumulator B to IO port

                  *******************************************************/
                  #if 1
                  oport(ea, b);
                  #else
                  if (ea < IO_PORTS) base[ea] = b;
                  if (ea == 102) indication |= b;
                  return;
                  #endif
               }

               if (designator == XI)
               {
                  /******************************************************

                        write staging _register                 sr.c

                        shift data bits from accumulator A to staging
                        _register WDATA, incrementing data bits count
                        in _register WDATAC. When WDATAC reaches 24
                        write WDATA to storage via pointer _register Q,
                        update Q and restart WDATAC

                  *******************************************************/

                  wsr(ea);
                  return;
               }

               /*********************************************************

                        SY instruction
                        store index _register Y

               *********************************************************/

               operand_write(y, ea, designator);

           return;

         __sa:
               if (designator ==  I)
               {
                  /*****************************************************

                        RELOAD instruction
                        used to reload the base registers from
                        the base table in the TCB on task switch

                  *****************************************************/

                  if (ea <  2) return;
                  if (ea > 62) return;

                  if ((burst_read2(buffer, a)) < 0) return;

                  if (buffer[0] & 0x00800000)
                  {
                     /**************************************************
                        implement bank index translation here
                     **************************************************/
                  }

                  base[ea] = buffer[0];

                  if (buffer[1] & 0x00800000)
                  {
                     /**************************************************
                        implement bank index translation here
                     **************************************************/
                  }

                  base[ea+1] = buffer[1];

                  a += 2;
                  a &= 0x00FFFFFF;
                  return;
               }

               if (designator == XI) return;

               /******************************************************

                        SA instruction
                        store accumulator A

               ******************************************************/

               operand_write(a, ea, designator);

           return;

         __sb:
               if (designator ==  I) return;
               if (designator == XI) return;

               /*********************************************************

                        SB instruction
                        store accumulator B

               *********************************************************/

               operand_write(b, ea, designator);

           return;

         __z:

               if (designator == I)
               {
                  /******************************************************
                        SABR instruction
                  *******************************************************/

                  sabr(a, ea);
                  return;
               }



               if (designator == XI)
               {
                  /*****************************************************
                        LRET            (local routine return)
                        return within current segment
                  ******************************************************/

                  STACK_RETURN(1)
                  _p = _register + v;
                  w = *_p;
                  w += ea;
                  w &= 0x00FFFFFF;
                  apc = &b0p->w[w];
                  v++;
                  *_q = v;

                  return;
               }

               /*********************************************************

                        Z instruction
                        store value zero

               *********************************************************/

               operand_write(0, ea, designator);

           return;

         __pop:

               if (designator == I) return;

               /*******************************************************
                                        spare
               *******************************************************/

               if (designator == XI)
               {
                  /******************************************************
                        FRET instruction (far routine return)

                        stepping 06.06.2019
                        alter the sp which you had before reading memory
                        because if the read gets a guard exception
                        sp is then name of the interrupt sp [iselect | SP]
                  *******************************************************/

                  STACK_RETURN(2)

                  _p = _register + v;
          
                  /***************************************************************
                     sp is updated immediately
                     authority or memory fault can raise after sp increment
                                     and before FRET instruction completion
                     this is in line with versions written in machine code
                  ***************************************************************/

                  v += 2;
                  *_q = v;

                  b0_name = *_p;

                  w = *(_p + 1);
                  w += ea;

                  base[0] = b0_scope = b0_name & 0x003FFFFF;
                  b0_name = *_p;
                  b0p = &memory.p4k[b0_scope];
                  apc = &b0p->w[w];

                  if (b0_name & 0x00800000)
                  {
                     b0_scope += b0p->w[64].t1 >> 2;
                  }

                  if (b0_scope > (PAGES_IN_MEMORY - 1))
                  {
                     GUARD_INTERRUPT
                     return;
                  }

                  if  (psr & 0x00800000)
                  {
                  }
                  else if (base[0] < base[72])
                  {
                     /*****************************************
                        must be an ISR to jump in there
                     *****************************************/

                     GUARD_AUTHORITY
                     return;
                  }

                  #ifdef INSTRUCTION_U
                  base[INSTRUCTION_U] = b0_scope;
                  apcz = &memory.p4k[b0_scope].w[4095];
                  #endif

                  return;
               }

               /***********************************************************

                        POP instruction
                        store word from the internal stack top

                        increment sp before operand write
                        in case the popped object is sp

               ***********************************************************/

               STACK_READ(1)
               _p = _register + v;
               *_q = v + 1;
               operand_write(*_p, ea, designator);

           return;



         __lr:
            case LR:

               /**********************************************************

                        load repeat _register R

               **********************************************************/

               OPERAND(v)
               r = v;

           return;

         __lk:

               /*********************************************************

                        load mask _register K

               *********************************************************/

               OPERAND(v)
               k = v;

           return;

         __lx:

               /*********************************************************

                        load index _register X

               *********************************************************/

               OPERAND(v)
               x = v;

           return;

         __ly:

               /********************************************************

                        load index _register Y

               ********************************************************/

               OPERAND(v)
               y = v;

           return;

         __la:

               /********************************************************

                        load accumulator A

               ********************************************************/

               _register[280] = ea;
               OPERAND(v)
               _register[281] = v;
               a = v;

           return;

         __lb:

               /********************************************************

                        load accumulator B

               ********************************************************/

               OPERAND(v)
               b = v;

           return;

         __tz:

               if (designator == I)
               {
                  /*****************************************************
                                repeat execute instruction
                  *****************************************************/

                  rex(ea);
                  return;
               }

               if (designator == XI)
               {
                  /******************************************************
                        II instruction (initiate internal interrupt)
                  *******************************************************/

                  /******************************************************
                        derive page # ea
                        ea is sign-extended but then &= 0x00FFFFFF
                  ******************************************************/

                  v = ea >> 6;

                  if (((v == 0) && ((psr & 0x00800000) == 0))
                  ||  (v >= base[72]))  /*      application threshold   */
                  {
                     /*********************************************
                        system call ii for applications
                        are not in the restart page
                     *********************************************/

                     GUARD_AUTHORITY;
                  }
                  else ii(ea, 0);
                  return;
               }

               /************************************************

                        TZ instruction

                        Test Zero and Skip

               ************************************************/

               OPERAND(v)

               if (v & 0x00FFFFFF)
               {
               }
               else apc++;

           return;

         __tp:

               if (designator == I)
               {
                  /******************************************************
                        JDZ instruction
                  *******************************************************/

                  if (((a) | (b)) & 0x00FFFFFF)
                  {
                  }
                  else apc = &b0p->w[ea];
                  return;
               }

               if (designator == XI)
               {
                  /******************************************************
                        IR instruction. return from interrupt
                  *******************************************************/

                  if (psr & 0x00800000)
                  {
                  }
                  else
                  {
                     /***************************************************
                        application issued ir instruction
                        not allowed
                     ***************************************************/

                     GUARD_AUTHORITY
                     return;
                  }

                  STACK_READ(4)
                  _p = _register + v;

                  v += 4;               /* update interrupt stack pointer */
                  *_q = v;              /* immediately in line with       */
                                        /* machine code written emulators */

                  /* latent parameter *sp not used on IR */

                  psr = _p[1];
                  b0_name = _p[2];
                  b0_scope = w = b0_name & 0x003FFFFF;
                  b0p = &memory.p4k[w];

                  if (b0_name & 0x00800000)
                  {
                     b0_scope += b0p->w[64].t1 >> 2;
                  }

                  if (b0_scope > (PAGES_IN_MEMORY - 1))
                  {
                     GUARD_INTERRUPT
                     return;
                  }

                  if  (psr & 0x00800000)
                  {
                  }
                  else if (w < base[72])
                  {
                     /****************************************
                        returning PSR is an application
                        must be an ISR to jump in there
                     *****************************************/

                     GUARD_AUTHORITY
                     return;
                  }

                  base[0] = w;

                  #ifdef INSTRUCTION_U  /* update the program counter limit */
                  base[INSTRUCTION_U] = b0_scope;
                  apcz = &memory.p4k[b0_scope].w[4095];
                  #endif

                  w = _p[3];
                  w += ea;
                  w &= 0x00FFFFFF;
                  apc = &b0p->w[w];     /* update the program counter   */

                  iselect = (psr & 0x00800000) >> 16;

                  return;
               }

               /************************************************

                        Test Positive and Skip

               ************************************************/

               OPERAND(v)

               if (v & 0x00800000)
               {
               }
               else apc++;

           return;



         __ax:

               /***********************************************

                        add operand to index _register X
                        
                        psr flag CARRY is not changed

               ************************************************/

               OPERAND(v)
               x = (x + v) & 0x00FFFFFF;
           return;

         __ay:
               
               /***********************************************

                        add operand to index _register Y
                        
                        psr flag CARRY is not changed

               ************************************************/

               OPERAND(v)
               y = (y + v) & 0x00FFFFFF;
           return;

         __or:

               /*****************************************************

                        OR instruction                  alu.c

                        or accumulator A with the operand value
                        
                        psr flag CARRY is not changed

               *****************************************************/

               OPERAND(v)
               a = a | v;
           return;

         __orB:

               /****************************************************

                        ORB instruction                 alu.c

                        or accumulator B with the operand value
                        
                        psr flag CARRY is not changed

               ****************************************************/

               OPERAND(v)
               b = b | v;
           return;

         __and:

               /***************************************************

                        AND instruction                 alu.c

                        and accumulator A with the operand value
                        
                        psr flag CARRY is not changed

               ****************************************************/

               OPERAND(v)
               a = a & v;
           return;

         __andB:

               /***************************************************

                        ANDB instruction                alu.c

                        and accumulator B with the operand value
                        
                        psr flag CARRY is not changed

               ****************************************************/

               OPERAND(v)
               b = b & v;
           return;

         __xor:

               /***************************************************

                        XOR instruction                 alu.c

                        xor accumulator A with the operand value
                        
                        psr flag CARRY is not changed

               ***************************************************/

               OPERAND(v)
               a = a ^ v;
           return;

         __xorB:

               /***************************************************

                        XORB instruction                 alu.c

                        xor accumulator B with the operand value

                        psr flag CARRY is not changed

               ***************************************************/

               OPERAND(v)
               b = b ^ v;
           return;



         __aa:

               /*************************************************

                        add to A                        alu.c

                        add the operand to accumulator A
                        
                        psr flag CARRY is updated

               **************************************************/

               OPERAND(v)
               v += a;
               a = v & 0x00FFFFFF;
               psr = (psr & 0x00FFFFFE) | ((v >> 24) & 1);
           return;

         __ab:

               /*************************************************

                        add to B                        alu.c

                        add the operand to accumulator B
                        
                        psr flag CARRY is updated

               *************************************************/

               OPERAND(v)
               v += b;
               b = v & 0x00FFFFFF;
               psr = (psr & 0x00FFFFFE) | ((v >> 24) & 1);
           return;

         __ana:

               /***********************************************************

                        add negative to A               alu.c

                        add the 2s complement of the operand
                        to accumulator A, i.e. subtract
                        
                        psr flag CARRY is updated

               ***********************************************************/

               OPERAND(v)
               v = (v ^ 0x00FFFFFF) + 1 + a;
               a = v & 0x00FFFFFF;
               psr = (psr & 0x00FFFFFE) | ((v >> 24) & 1);

           return;

         __anb:

               /***********************************************************

                        add negative to B               alu.c

                        add the 2s complement of the operand
                        to accumulator B, i.e. subtract
                        
                        psr flag CARRY is updated

               **********************************************************/

               OPERAND(v)
               v = (v ^ 0x00FFFFFF) + 1 + b;
               b = v & 0x00FFFFFF;
               psr = (psr & 0x00FFFFFE) | ((v >> 24) & 1);
           return;

         __m_:	/*	__m_ because __m() is an external function in alu.c	*/

               /**********************************************************

                        multiply                        alu.c

                        multiply _register B by the operand
                        algebraically, giving a 48-bit product
                        in accumulators A:B
                        
                        psr flag CARRY is not changed

               ***********************************************************/

               __m(ea, designator, &a);
           return;

         __mf_:	/*	 __mf_ because __mf() is an external function in alu.c	*/

               /***********************************************************

                        multiply fractional             alu.c

                        multiple accumulator B by the operand
                        giving a 48-bit product in accumulators A:B

                        B is treated as unsigned
                        the operand is treated as signed
                        
                        psr flag CARRY is not changed

               ***********************************************************/

               __mf(ea, designator, &a);
           return;

         __d_:	/*	 __d_ because __d() is an external function in alu.c	*/

               /***********************************************************

                        divide                          alu.c

                        divide the 48-bit dividend in accumulators A:B
                        by the operand algebraically.

                        store the quotient in A and the remainder in B

                        quotient high-order bits 47..24 are stored in
                        register 6 MANTISSA2 (register 134 in ISR mode)

                        psr flag CARRY is not changed

                **********************************************************/

               __d(ea, designator, &a);
           return;

         __push:

               /**********************************************************

                        place a word on the internal stack

                        acquire operand before decrementing sp
                        in case the pushed object is sp

                        sp at *_q is the same one before and after
                        even if a fault occurs in burst_read

               **********************************************************/

               STACK(1)
               v--;
               _p = _register + v;
              if ((*_p = operand_read(ea, designator)) < 0) return;
              *_q = v;

           return;

   }
}

