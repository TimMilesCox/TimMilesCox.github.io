/*********************************************************************

    Copyright Tim Cox, 2012
    TimMilesCox@gmx.ch

    This file is part of the emulated-instruction-execution-subsection
    of the software-emulation of the freeware processor architecture

                RTA1

    RTA1 is a free processor architecture design.

    The executable emulation of RTA1 is free software.

    Instruction code for the target RTA1 architecture is free software
    if it is delivered with this software

    Software programs delivered with this software to connect the
    emulated RTA1 with real network interfaces in the emulator host
    are free software

    Scripts and programs delivered with this software for running
    on other computers and interacting with the RTA1 are free software

    Scripts and utility programs for constructing RTA1 target
    executable software are free software

    You can redistribute it and/or modify RTA1
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version. 

    RTA1 is distributed in the hope that it will be useful,     
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with RTA1.  If not, see <http://www.gnu.org/licenses/>.

**********************************************************************/

#ifdef	X86_MSW
#include <windows.h>
#endif

#include <stdio.h>
#include "emulate.h"
#include "fpu.h"
#include "rw.h"
// include "alu.h"
#include "sr.h"
#include "ii.h"
#include "stack.h"

#include "../rta.run/settings.h"

#ifdef	EDGE
#include "../rta.run/idisplay.h"
#endif

extern int			 indication;

extern system_memory		 memory;
#define ROM_PAGE		 &memory.p4k[0].w[0];
extern device			 devices[];

int		 psr = 0x00800000;
word		*apc = ROM_PAGE;

#ifdef	INSTRUCTION_U
word		*apcz = &memory.p4k[0].w[4095];
#endif

int		 iselect = 128;
int		 contingency;
int		 b0_name;
unsigned	 b0_scope;
page		*b0p = memory.p4k;

int		 _register[REGISTERS];

int		*register_set = _register + 128;

#include "../tgen.x64/ioports.c"
#include "../engine.rta/ioportab.c"

static void sr(int ea, int designator);
static void sk(int ea, int designator);
static void sx(int ea, int designator);
static void sy(int ea, int designator);
static void sa(int ea, int designator);
static void sb(int ea, int designator);
static void z(int ea, int designator);
static void pop(int ea, int designator);
static void lr(int ea, int designator);
static void lk(int ea, int designator);
static void lx(int ea, int designator);
static void ly(int ea, int designator);
static void la(int ea, int designator);
static void lb(int ea, int designator);
static void tz(int ea, int designator);
static void tp(int ea, int designator);

static void ax(int ea, int designator);
static void ay(int ea, int designator);
static void  or(int ea, int designator);	/*	OR with register A	*/
static void orB(int ea, int designator);	/*	OR with register B	*/
static void and(int ea, int designator);	/*	AND with register A	*/
static void andB(int ea, int designator);	/*	AND with register B	*/
static void xor(int ea, int designator);	/*	XOR with register A	*/
static void xorB(int ea, int designator);	/*	XOR with register B	*/
static void  aa(int ea, int designator);	/*	add to A		*/
static void  ab(int ea, int designator);	/*	add to B		*/
static void ana(int ea, int designator);	/*	add negative to A	*/
static void anb(int ea, int designator);	/*	add negative to B	*/
static void   m(int ea, int designator);	/*	multiply		*/
static void  mf(int ea, int designator);	/*	multiply fractional	*/
static void   d(int ea, int designator);	/*	divide			*/
static void push(int ea, int designator);	/*	load [ea] -> --*sp	*/

static void ts(int ea);
static void n(int ea);
static void inc(int ea);
static void dec(int ea);

static void sim(int ea);
static void popA(int ea);
static void src(int ea);
static void slc(int ea);

static void qs(int ea);
static void ql(int ea);
static void dte(int ea);
static void dpop(int ea);

static void fa(int ea);
static void fan(int ea);
static void fm(int ea);
static void fd(int ea);

static void qpop(int ea);
static void qpush(int ea);
static void ex(int ea);
static void dpush(int ea);

extern void lsc(int ea);
static void mta(int ea);
static void sc(int ea);
static void mlb(int ea);

static void dl(int ea);
static void ds(int ea);
static void da(int ea);
static void dan(int ea);

extern void dlsc(int ea);
static void nop7(int ea);
static void go(int ea);
static void call(int ea);

extern void sar(int ea);
extern void sbr(int ea);
extern void dsr(int ea);
static void jdr(int ea);

extern void sal(int ea);
extern void sbl(int ea);
extern void dsl(int ea);
static void lcal(int ea);

extern void rar(int ea);
extern void rbr(int ea);
extern void drr(int ea);
static void jnc(int ea);

extern void ral(int ea);
extern void rbl(int ea);
extern void drl(int ea);
static void jc(int ea);

extern void saa(int ea);
extern void sba(int ea);
extern void dsa(int ea);
static void jao(int ea);

static void jpa(int ea);
static void jpb(int ea);
static void j(int ea);
static void jpo(int ea);

static void jza(int ea);
static void jzb(int ea);
static void jnza(int ea);
static void jnzb(int ea);

static void jna(int ea);
static void jnb(int ea);
static void jxge(int ea);
static void jyge(int ea);

extern void __or(int ea, int designator, int *target);
extern void __and(int ea, int designator, int *target);
extern void __xor(int ea, int designator, int *target);
extern void __aa(int ea, int designator, int *target);
extern void __ana(int ea, int designator, int *target);
extern void __m(int ea, int designator, int target[]);
extern void __mf(int ea, int designator, int target[]);
extern void __d(int ea, int designator, int target[]);
extern void __da(int ea, int target[]);
extern void __dan(int ea, int target[]);
extern void __fa(int ea, int target[]);
extern void __fan(int ea, int target[]);
extern void __fm(int ea, int target[]);
extern void __fd(int ea, int target[]);


static void (* p1[32])(int, int) = {	sr, sk, sx, sy, sa, sb, z, pop,
					lr, lk, lx, ly, la, lb, tz, tp,
					ax, ay, or, orB, and, andB, xor, xorB,
					aa, ab, ana, anb, m, mf, d, push } ;

static void (* p6[32])(int)	 = {	sar, sbr, dsr, jdr, sal, sbl, dsl, lcal,
					rar, rbr, drr, jnc, ral, rbl, drl, jc,
					saa, sba, dsa, jao, jpa, jpb, j, jpo,
					jza, jzb, jnza, jnzb, jna, jnb, jxge, jyge } ;

static void (* p7[32])(int)	 = {	ts, n, inc, dec, sim, popA, src, slc,
					qs, ql, dte, dpop, fa, fan, fm, fd,
					qpop, qpush, ex, dpush, lsc, mta, sc, mlb,
					ds, dl, da, dan, dlsc, nop7, go, call } ;

static void oport(int ea, int value)
{
   int		 rule,
                 device;

   if (ea < IO_PORTS)
   {
      rule = mask_port_outAB[ea];

      if (rule)
      {
         if (((rule & ISR_ONLY) == 0) || (psr & 0x00800000))
         {
            if (rule & EXTERNAL_IO)
            {
               base[ea] = value;
               if (ea == 102) indication |= value;
               if (ea == 75) base[74] &= (value & 255) ^ 255;
               if ((ea == 79) && (value & 1)) indication |= ATTENTION;
               return;
            }
            else if (rule & MEMTYPE)
            {
               if (value & 0x00400000) device = base[128+(value & 63)];
               else device = base[128];
           
               if ((device & 0x00C00000) == 0x00800000)
               {
                  if ((value & 0x00BFFFC0) > (device & 0x003FFFFF))
                  {
                  }
                  else
                  {
                     base[ea] = value;
                     return;
                  }
               }
            }
            else
            {
               /*******************************************
		page pointer to system memory
               *******************************************/

               if ((value & 0x00400000) == 0)
               {
                  if (value > (base[128] & 0x003FFFFF))
                  {
                  }
                  else
                  {
                     base[ea] = value;
                     return;
                  }
               }
            }
         }
      }
   }

   GUARD_AUTHORITY;
}

void execute(word instruction)
{
   int		 designator = instruction.t1 & 7;
   int		 ocode = (unsigned char) instruction.t1 >> 3;
   int		 ea, xtag;

   int		*_p,
		*_q;

   int		 v, w, device_index;
   unsigned	 device_descriptor;
   int		 buffer[4];
   device	*devicep;

   word		*_w;

   contingency = 0;		/* no guard fault this far this instruction */
   EFFECTIVE_ADDRESS;
 
   if      (designator < 6) p1[ocode] (ea, designator);
   else if (designator > 6) p7[ocode] (ea);
   else                     p6[ocode] (ea);

   #ifdef LP_TSLICE
   #define icount w
   if (psr & 0x00870000)
   {
      /***************************************************
             not during interrupt
             or with interrupt lock
      ***************************************************/
   }
   else
   {
      if ((icount = _register[REALTIME_CLOCK] & 0x00FFFFFF))
      {
         icount--;
         _register[REALTIME_CLOCK] = icount;
         if (!icount) ii(YIELD, LP_TSLICE);
      }
   }
   #endif
}

static void jdr(int ea)
{ 
              /****************************************************

                        jump decrement R

                        always decrement R
                        jump unless R was zero before the instruction

               *****************************************************/

               int v = (r & 0x00FFFFFF) + 0x00FFFFFF;
               r = v & 0x00FFFFFF;
               if (v & 0x01000000) apc = &b0p->w[ea];

}

static void lcal(int ea)
{
               /****************************************************

                        local call

                        push the saved program counter
                        = location of following instructiom
                        = absolute program counter minus base B0
                        on the internal stack

                        jump to ea

                ****************************************************/

   int          *_p,
                *_q;

   int           v;


               STACK(1)
               v--;
               _p = _register + v;
               *_p = apc - b0p->w;
               *_q = v;

               apc = &b0p->w[ea];
}


static void jnc(int ea)
{				/* 	jump no carry		*/
	       if ((psr & CARRY) == 0) apc = &b0p->w[ea];
}

static void jc(int ea)				/* jump carry			*/
{
	       if (psr & CARRY) apc = &b0p->w[ea];
}

static void jao(int ea)
{
               if (a & 1) apc = &b0p->w[ea];
}

static void jpa(int ea)
{
               /****************************************************

			jump positive A

			jump if bit 23 of A is clear

               *****************************************************/


               if (a & 0x00800000)
               {
               }
               else apc = &b0p->w[ea];
}

static void jpb(int ea)
{
               /****************************************************

			jump positive B

			jump if bit 23 of B is clear

		****************************************************/


               if (b & 0x00800000)
               {
               }
               else apc = &b0p->w[ea];
}

static void j(int ea)
{
               /******************************************************
                        J instruction. Jump intra bank
               *******************************************************/

               apc = &b0p->w[ea];
}

static void jpo(int ea)
{
               int v = a & k;
               v &= 0x00FFFFFF;
               v ^= v >> 16;
               v ^= v >>  8;
               v ^= v >>  4;
               v ^= v >>  2;
               v ^= v >>  1;

               if (v & 1)  apc = &b0p->w[ea];
}

static void jza(int ea)
{
	       if (a & 0x00FFFFFF)
               {
               }
               else apc = &b0p->w[ea];
}

static void jzb(int ea)
{
	       if (b & 0x00FFFFFF)
	       {
               }
               else  apc = &b0p->w[ea];
}

static void jnza(int ea)
{
               if (a & 0x00FFFFFF) apc = &b0p->w[ea];
}

static void jnzb(int ea)
{
               if (b & 0x00FFFFFF) apc = &b0p->w[ea];
}

static void jna(int ea)
{
               if (a & 0x00800000) apc = &b0p->w[ea];
}

static void jnb(int ea)
{
               if (b & 0x00800000) apc = &b0p->w[ea];
}

static void jxge(int ea)
{
               /******************************************************
                        JXGE instruction (jump x not less than r)
               ******************************************************/

               if ((x & 0x00FFFFFF) < (r & 0x00FFFFFF))
               {
               }
               else apc = &b0p->w[ea];
}

static void jyge(int ea)
{
               /******************************************************
                        JYGE instruction (jump y not less than r)
               ******************************************************/

               if ((y & 0x00FFFFFF) < (r & 0x00FFFFFF))
               {
               }
               else apc = &b0p->w[ea];
}

static void ts(int ea)
{
               /*************************************************

			test and set

			always set bit 23 of the storage
			operand

			skip next instruction if that bit
			was previously clear

			touch no flags

               *************************************************/


               #ifdef ABSOTS

               /************************************************
                  operand_read() and operand_write()
                  don't look at the designator argument
                  before classing EA in register range
                  so switch ABSO uses * _w = memory_hold(ea)
                  to get a pointer for TS instruction
                  and that is one less call to operand_etc()

                  of course TS target is never in range 0..255
               ************************************************/

               int v;;

	       word *_w = memory_hold(ea);
               if (contingency < 0) return;
               if (_w == NULL) return;
               v = _w->t1;
               v ^= 128;

               if (v & 128)
               {
                  _w->t1 = v;
                  apc++;
               }

               #else

               int v = operand_read(ea, 7);
               if (contingency < 0) return;
               v ^= 0x00800000;

               if (v & 0x00800000)
               {
                  operand_write(v, ea, 7);
                  apc++;
               }

               #endif
}

static void n(int ea)
{
               /************************************************

			negate

			ones complement invert the storage
			operand

			touch no flags

               ************************************************/

               int v = operand_read(ea, 7);
               if (contingency < 0) return;
               v ^= 0x00FFFFFF;
               operand_write(v, ea, 7);
}

static void inc(int ea)
{
               /***********************************************

			increment

			touch no flags

               ***********************************************/

               int v = operand_read(ea, 7);
               if (contingency < 0) return;
               v++;
               operand_write(v & 0x00FFFFFF, ea, 7);
}

static void dec(int ea)
{
               /**************************************************

			decrement

			touch no flags

               **************************************************/

               int v = operand_read(ea, 7);
               if (contingency < 0) return;
               v--;
               operand_write(v & 0x00FFFFFF, ea, 7);
}

static void sim(int ea)
{
               /**************************************************

			switch interrupt mask

			exchange the interrupt mask in PSR 22..16
			with the value in the storage operand

               **************************************************/

               int v = operand_read(ea, 7);
               if (contingency < 0) return;
               operand_write(((psr >> 16) & 0x7F), ea, 7);
               psr &= (0x0080FFFF);
               psr |= (v & 0x7F) << 16;
}

static void popA(int ea)
{
               /**************************************************

			pop and add

			take a word form the internal stack
			and add it to the target word

		        25th bit of sum -> carry

			increment sp after operand read
                        and before operand write

			*_q -> is the same sp even before and after
                        even if operand read faults

               **************************************************/

   int          *_p,
                *_q;

   int           v,
		 w;

               STACK_READ(1)
               _p = _register + v;
               w = *_p;
               w += operand_read(ea, 7);
               if (contingency < 0) return;

               v++;
               *_q = v;

               psr &= (0x00FFFFFE);
               psr |= ((w >> 24) & 1);
               operand_write(w & 0x00FFFFFF, ea, 7);
}

static void src(int ea)
{
               /*************************************************

			shift right through carry

			25-bit rotate one bit position
			to the right

			carry moves into high bit of storage operand
			low bit of the storage operand moves into carry

			touch no other flags

               *************************************************/

               int v = operand_read(ea, 7);
               if (contingency < 0) return;
               operand_write((v >> 1) | ((psr & CARRY) << 23),
                             ea, 7);
               psr &= CARRY^0x00FFFFFF;
               psr |= v & 1;
}

static void slc(int ea)
{
               /*************************************************

			shift left through carry

			25-bit rotate one bit position
			to the left

			carry moves into low bit of storage operand
			high bit of the storage operand moves into carry

			touch no other flags

               *************************************************/

               int v = operand_read(ea, 7);
               if (contingency < 0) return;
               operand_write(0x00FFFFFF & ((v << 1) | (psr & CARRY)), ea, 7);
               psr &= CARRY^0x00FFFFFF;
               psr |= (v & 0x00800000) >> 23;               
}

static void qs(int ea)
{
               /*************************************************

			quadruple store

			store the four accumulators A:B:6:7

               *************************************************/

               burst_write4(&a, ea);
} 

static void ql(int ea)
{
               /*************************************************

			quadruple load

			load the four accumulators A:B:6:7

               *************************************************/

               burst_read4(&a, ea);
}

static void fa(int ea)
{
               /*************************************************

			floating add			fpu.c

			add the four-word floating-point operand
			to the floating-point value in the four
			accumulators A:B:6:7

               *************************************************/

               __fa(ea, &a);
}

static void fan(int ea)
{
               /*************************************************

			floating add negative		fpu.c

			add the negative (i.e. subtract the value)
			of the four-word floating-point operand
         		to the floating-point value in the four
			accumulators A:B:6:7

               *************************************************/

               __fan(ea, &a);
}

static void fm(int ea)
{
               /*************************************************

			floating multiply		fpu.c

			multiply the floating-point value
			in the four accumulators A:B:6:7
			by the four-word floating-point operand

               *************************************************/

               __fm(ea, &a);
 
}

static void fd(int ea)
{
               /*************************************************

			floating divide			fpu.c

			divide the floating-point value
			in the four accumulators A:B:6:7
			by the four-word floating-point operand

               *************************************************/

               __fd(ea, &a);
}

static void dpop(int ea)
{
               /*************************************************

                        double pop

                        pop two words from the internal
                        stack top

                        decrement sp before burst write
                        in case the popped objects include sp

               *************************************************/

   int          *_p,
                *_q;

   int           v;

               STACK_READ(2);
               _p = _register + v;
               *_q = v + 2;

               burst_write2(_p, ea);
}

static void qpop(int ea)
{
               /*************************************************

			quadruple pop

			pop four words from the internal
			stack top

			decrement sp before burst write
			in case the popped objects include sp

               *************************************************/

   int          *_p,
                *_q;

   int           v;

               STACK_READ(4)
               _p = _register + v;
               *_q = v + 4;

               burst_write4(_p, ea);
}

static void qpush(int ea)
{
               /*************************************************

			quadruple push

			push four words onto the internal
			stack top

			acquire operands before decrementing sp
			in case the pushed objects include sp

			sp at *_q is the same one before and after
			even if a fault occurs in burst_read

               *************************************************/

   int          *_p,
                *_q;

   int           v;

               STACK(4)
               v -= 4;
               _p = _register + v;
               burst_read4(_p, ea);
               if (contingency < 0) return;

               *_q = v;
}

static void ex(int ea)
{
               /*************************************************

			execute

			read an instruction word from storage
			and execute it

               *************************************************/

               word xqt = memory_read(ea);
               if (contingency < 0) return;

               execute(xqt);
}

static void dpush(int ea)
{
               /*************************************************

			double push

			push two words onto the internal
			stack top

                        acquire operands before decrementing sp
                        in case the pushed objects include sp

                        sp at *_q is the same one before and after
                        even if a fault occurs in burst_read

               *************************************************/

   int          *_p,
                *_q;

   int           v;

               STACK(2)
               v -= 2;
               _p = _register + v;
               burst_read2(_p, ea);
               if (contingency < 0) return;
               *_q = v;
}

#if 0

	direct call to alu block

static void lsc(int ea)
{
               /*************************************************

			load shift and count		alu.c

			load accumulator A from storage and shift
			left until bit 23 is not the sign polarity

			stop at 24 if all bits = sign

			shift count in accumulator B

               *************************************************/

               lsc(ea);
}

#endif

static void mta(int ea)
{
               /*************************************************

			masked test A			alu.c

			test subtract
			storage operand AND mask _register K
			from accumulator A AND mask _register K

			skip next instruction if equal

               *************************************************/


               
               int v = operand_read(ea, 7);
               if (contingency < 0) return;


               if ((a & k) ^ (v & k))
               {
               }
               else apc++;
}

static void dte(int ea)
{
               /*************************************************

			double test subtract [ a b ] - operand
			skip equal 

               *************************************************/

               int		 buffer[2];

               burst_read2(buffer, ea);
               if (contingency < 0) return;

               if ((a ^ buffer[0]) | (b ^ buffer[1]))
               {
               }
               else apc++;
}

static void sc(int ea)
{
               /*************************************************

			store carry

			store the value if the CARRY flag
			as a data word containing zero or one

               *************************************************/

               operand_write(psr & CARRY, ea, 7);
}

static void mlb(int ea)
{
               /*************************************************

			masked load B

			accumulator B = (B AND (NOT mask _register K))
			OR (storage operand AND mask _register K)

               **************************************************/

               int v;
	       int buffer = operand_read(ea, 7);
               if (contingency < 0) return;

               v = k & 0x00FFFFFF;
               b = (b & (v ^ 0x00FFFFFF)) | (buffer & v);
}

static void ds(int ea)
{
               /*************************************************

			double store

			store the two accumulators A:B

               *************************************************/

               burst_write2(&a, ea);
}

static void dl(int ea)
{
               /*************************************************

			double load

			load the two accumulators A:B

               *************************************************/

               burst_read2(&a, ea);

               #ifdef EDGE
               if (psr & 32768) q4readout();
               #endif
}

static void da(int ea)
{
               /*************************************************

			double add			alu.c

			add the two-word integer from storage
			to accumulators A:B

			set or clear CARRY

               *************************************************/

               __da(ea, &a);
}

static void dan(int ea)
{
               /*************************************************

			double add negative		alu.c

			add the negative (i.e. subtract the value)
			of two-word integer from storage
			to accumulators A:B

			set or clear CARRY

               *************************************************/

               __dan(ea,  &a);
}

#if 0
	direct call to alu section

static void dlsc(int ea)
{
               /*************************************************

			double load shift and count	alu.c

			load accumulators A:B from storage and shift
			left until bit 47 is not the sign polarity

			stop at 48 if all bits = sign

			shift count in accumulator _register 6

               *************************************************/

               dlsc(ea);
}
#endif

static void nop7(int ea)
{
}

static void call(int ea)
{
               /*********************************************************

			same as GO except offset and bank of following
			instruction are first placed in the internal
			stack where far return instruction FRET should
			find them later

               **********************************************************/

   int          *_p,
                *_q;

   int           v;

               STACK(2)
               v -= 2;
               _p = _register + v;
               _p[1] = apc - b0p->w;
               _p[0] = b0_name;
               *_q = v;
               go(ea);
}

static void go(int ea)
{
               /***************************************************

			switch instruction base B0 according to
			bits 23..6 of the operand word loaded from
			storage

			jump to location 0..63 of the new B0 bank
			according to bits 6..0 of the operand word

               ***************************************************/

               int	 v,
			 w;

               int	 buffer[2];


               b0_name = operand_read(ea, 7);
               if (contingency < 0) return;

               if (b0_name & 0x00800000)
               {
                  /************************************************
			read the gate
                  ************************************************/

                  burst_read2(buffer, b0_name & 0x007FFFFF);
                  if (contingency < 0) return;
                  b0_name = buffer[1];
                  if (buffer[0] & 0x00FC0000) b0_name |= 0x00800000;
                  b0_scope = b0_name & 0x003FFFFF;
                  v = b0_scope;
                  b0_scope += buffer[0] >> 18;
                  w = buffer[0] & 262143; 
               }
               else
               {
                  b0_name &= 0x003FFFFF;	/* bit 22 is reserved */
                  w = b0_name & 63;
                  b0_name >>= 6;
                  v = b0_name;
                  b0_scope = v;
               }

               if (b0_scope > (PAGES_IN_MEMORY - 1))
               {
                  GUARD_INTERRUPT
                  return;
               }

               if  (psr & 0x00800000)
               {
               }
               else if (v < base[72])
               {
                  /*****************************************
                     must be an ISR to jump in there
                  *****************************************/

                  GUARD_AUTHORITY
                  return;
               }

               base[0] = v;
               b0p = &memory.p4k[v];
               apc = &b0p->w[w];

               #ifdef INSTRUCTION_U
               base[INSTRUCTION_U] = b0_scope;
               apcz = &memory.p4k[b0_scope].w[4095];
               #endif
} 
 
static void sr(int ea, int designator)
{
               if (designator == I)
               {
                  /******************************************************

			INA instruction
			read IO port to accumulator A

                  *******************************************************/

                  a = 0x00FFFFFF;
                  if (ea < IO_PORTS) a = base[ea];
                  return;
               }
 
               if (designator == XI)
               {
                  /******************************************************

                        ON instruction (or PSR flags)

                  *******************************************************/

                  psr |= ea & 65535;
                  return;
               }

               /*********************************************************

			SR instruction
			store repeat _register R

               *********************************************************/

               operand_write(r, ea, designator);
} 
 
static void sk(int ea, int designator)
{
              if (designator == I)
               {
                  /******************************************************

                        INB instruction
			read IO port to accumulator B

                  *******************************************************/

                  b = 0x00FFFFFF;
                  if (ea < IO_PORTS) b = base[ea];
                  return;
               }
               
               if (designator == XI)
               {
                  /******************************************************

                        OFF instruction (nor PSR flags)

                  *******************************************************/
               
                  psr &= (ea & 65535) ^ 0x00FFFFFF;
                  return;
               }

               /*********************************************************

			SK instruction
			store mask _register K

               *********************************************************/

               operand_write(k, ea, designator);
}
 
static void sx(int ea, int designator)
{
              if (designator == I)
               {
                  /******************************************************

                        OUTA instruction
			write accumulator A to IO port

                  *******************************************************/

                  #if 1
                  oport(ea, a);
                  #else
                  if (ea < IO_PORTS) base[ea] = a;
                  if (ea == 102) indication |= a;
                  #endif

                  return;
               }
               
               if (designator == XI)
               {
                  /******************************************************

                        read staging _register			sr.c

			shift bits from staging _register RDATA to
			accumulator A, decrementing available data bits
			count in _register RDATAC. Read memory
			via pointer _register Q and update Q if more
			data required

                  *******************************************************/
               
                  rsr(ea);
                  return;
               }

               /********************************************************

			SX instruction
			store index _register X

               *********************************************************/

               operand_write(x, ea, designator);
}

static void sy(int ea, int designator)
{
               if (designator == I)
               {
                  /******************************************************

                        OUTB instruction
			write accumulator B to IO port

                  *******************************************************/
                  #if 1
                  oport(ea, b);
                  #else
                  if (ea < IO_PORTS) base[ea] = b;
                  if (ea == 102) indication |= b;
                  return;
                  #endif
               }

               if (designator == XI)
               {
                  /******************************************************

                        write staging _register			sr.c

			shift data bits from accumulator A to staging
			_register WDATA, incrementing data bits count
			in _register WDATAC. When WDATAC reaches 24
			write WDATA to storage via pointer _register Q,
			update Q and restart WDATAC

                  *******************************************************/

                  wsr(ea);
                  return;
               }

               /*********************************************************

			SY instruction
			store index _register Y

               *********************************************************/

               operand_write(y, ea, designator);
}

static void sa(int ea, int designator)
{
               int	 buffer[2];

               if (designator ==  I)
               {
                  /*****************************************************

			RELOAD instruction
			used to reload the base registers from
			the base table in the TCB on task switch

                  *****************************************************/

                  if (ea <  2) return;
                  if (ea > 62) return;

                  burst_read2(buffer, a);

                  if (buffer[0] & 0x00800000)
                  {
                     /**************************************************
			implement bank index translation here
                     **************************************************/
                  }

                  base[ea] = buffer[0];

                  if (buffer[1] & 0x00800000)
                  {
                     /**************************************************
			implement bank index translation here
                     **************************************************/
                  }

                  base[ea+1] = buffer[1];

                  a += 2;
                  a &= 0x00FFFFFF;
                  return;
               }

               if (designator == XI) return;

               /******************************************************

			SA instruction
			store accumulator A

               ******************************************************/

               operand_write(a, ea, designator);
}

static void sb(int ea, int designator)
{
               if (designator ==  I) return;
               if (designator == XI) return;

               /*********************************************************

			SB instruction
			store accumulator B

               *********************************************************/

               operand_write(b, ea, designator);
}

static void z(int ea, int designator)
{
   int           v, w, device_index;
   unsigned      device_descriptor;
   int           buffer[4];
   device       *devicep;
   word		*_w;

               if (designator == I)
               {
                  /******************************************************
                        SABR instruction
                  *******************************************************/

                  if ((ea > 1) && (ea < 64))
                  {
                     v = a;

                     if ((v & 0x00400000) && (device_index = v & 63))
                     {
                        /*********************************************
                           yes that is intended to be an assignment

                           device array outside system memory
                           only interrupt code may base it
                           unless it is array memory
                           with bus behaviour like system memory
                        *********************************************/

                        /********************************************
                           allowed for interrupt code but check
                        ********************************************/

                        #ifdef CHECK_ON_BASE
                        device_descriptor = base[128 + device_index];
                              
                        switch (device_descriptor & 0x00C00000)
                        {
                           case SYSMEM_FLAG:
                              /*************************************
				applications and ISRs
				may both base array memory
                              *************************************/

                              if (((v & 0x003FFFC0) | 63)
                              >   (device_descriptor & 0x003FFFFF)) v = 0x00C00001;

                              break;

                           case DATA16_FLAG:
                           case FSYS24_FLAG:

                              if (psr & 0x00800000)
                              {
                                 /**********************************
                                     ISRs may base peripheral arrays
                                     if the block is in range
                                 **********************************/

                                 if (((v >> 6) & 65535)
                                 >   (base[128 + device_index] & 65535)) v = 0x00C00001;
                              }
                              else
                              {
                                 /**********************************
                                    whereas applications may not
                                    too easy to do inadvertantly
                                 **********************************/

                                 ii(XBASE_U, LP_AUTHORITY);
                                 return;
                              }

                              break;

                           default:
                              /**********************************
				flag value 00 void device
                              **********************************/

                              v = 0x00C00001;
                        }
                        #endif
                     }

                     #ifdef CHECK_ON_BASE
                     else if ((v & 0x00BFFFFF) < base[72])
                     {
                        /***********************************************
                           no-one pulls up the restart and ISR pages
                           into their operand space
                           covers register a accidentally zero
                        ***********************************************/

                        v = 0x00C00001;
                     }
                     else if ((v & 0x00BFFFFF) < PAGES_IN_MEMORY)
                     {
                        /***********************************************
                           you're fine
                        ***********************************************/
                     }
                     else
                     {
                        /***********************************************
                           no such block of storage
                        ***********************************************/

                        v = 0x00C00001;
                     }
                     #endif

                     w = base[65] & 0x0000FFFF;

                     _w = &memory.p4k[w].w[BASE_TABLE+ea];

                     _w->t3 = v;
                     _w->t2 = v >> 8;
                     _w->t1 = v >> 16;

                     #if 0
                     if (v & 0x00800000)
                     {
                        /************************************************
                                implementations with bank index
                                translation have that here
                        ************************************************/
                     }
                     #endif

                     base[ea] = v;
                  }
                  else
                  {
                     /**************************************************
				window tag < 2 or > 63
                     **************************************************/

                     ii(XBASE_U, LP_AUTHORITY);
                  }

                  return;
               }


               if (designator == XI)
               {
                  /*****************************************************
			LRET		(local routine return)
			return within current segment
		  ******************************************************/

   int          *_p,
                *_q;

   int           v,
		 w;

                  STACK_RETURN(1)
                  _p = _register + v;
                  w = *_p;
                  w += ea;
                  w &= 0x00FFFFFF;
                  apc = &b0p->w[w];
                  v++;
                  *_q = v;

                  return;
               }

               /*********************************************************

			Z instruction
			store value zero

               *********************************************************/

               operand_write(0, ea, designator);
} 

static void pop(int ea, int designator)
{
   int          *_p,
                *_q;

   int           v,
		 w;

               if (designator == I) return;

               /*******************************************************
                                        spare
               *******************************************************/



               if (designator == XI)
               {
                  /******************************************************
                        FRET instruction (far routine return)

                        stepping 06.06.2019
                        alter the sp which you had before reading memory
                        because if the read gets a guard exception
                        sp is then name of the interrupt sp [iselect | SP]
                  *******************************************************/

                  STACK_RETURN(2)

                  _p = _register + v;
          
                  /***************************************************************
                     sp is updated immediately
                     authority or memory fault can raise after sp increment
                                     and before FRET instruction completion
                     this is in line with versions written in machine code
                  ***************************************************************/

                  v += 2;
                  *_q = v;

                  b0_name = *_p;

                  w = *(_p + 1);
                  w += ea;

                  base[0] = b0_scope = b0_name & 0x003FFFFF;
                  b0_name = *_p;
                  b0p = &memory.p4k[b0_scope];
                  apc = &b0p->w[w];

                  if (b0_name & 0x00800000)
                  {
                     b0_scope += b0p->w[64].t1 >> 2;
                  }

                  if (b0_scope > (PAGES_IN_MEMORY - 1))
                  {
                     GUARD_INTERRUPT
                     return;
                  }

                  if  (psr & 0x00800000)
                  {
                  }
                  else if (base[0] < base[72])
                  {
                     /*****************************************
                        must be an ISR to jump in there
                     *****************************************/

                     GUARD_AUTHORITY
                     return;
                  }

                  #ifdef INSTRUCTION_U
                  base[INSTRUCTION_U] = b0_scope;
                  apcz = &memory.p4k[b0_scope].w[4095];
                  #endif

                  return;
               }

               /***********************************************************

			POP instruction
			store word from the internal stack top

			increment sp before operand write
			in case the popped object is sp

               ***********************************************************/

               STACK_READ(1)
               _p = _register + v;
               *_q = v + 1;
               operand_write(*_p, ea, designator);
}

static void lr(int ea, int designator)
{
               /**********************************************************

			load repeat _register R

               **********************************************************/

               int v = operand_read(ea, designator);
               if (contingency < 0) return;
               r = v & 0x00FFFFFF;
}

static void lk(int ea, int designator)
{
               /*********************************************************

			load mask _register K

               *********************************************************/

               int v = operand_read(ea, designator);
               if (contingency < 0) return;
               k = v & 0x00FFFFFF;
}

static void lx(int ea, int designator)
{
               /*********************************************************

			load index _register X

               *********************************************************/

               int v = operand_read(ea, designator);
               if (contingency < 0) return;
               x = v & 0x00FFFFFF;
}

static void ly(int ea, int designator)
{
               /********************************************************

			load index _register Y

               ********************************************************/

               int v = operand_read(ea, designator);
               if (contingency < 0) return;
               y = v & 0x00FFFFFF;
}

static void la(int ea, int designator)
{
               /********************************************************

			load accumulator A

               ********************************************************/

               int v = operand_read(ea, designator);
               if (contingency < 0) return;
               a = v & 0x00FFFFFF;
}

static void lb(int ea, int designator)
{
               /********************************************************

			load accumulator B

               ********************************************************/

               int v = operand_read(ea, designator);
               if (contingency < 0) return;
               b = v & 0x00FFFFFF;
} 

static void tz(int ea, int designator)
{
               int		 v;

               if (designator == I) return;

               /*******************************************************
					spare
               *******************************************************/


               if (designator == XI)
               {
                  /******************************************************
                        II instruction (initiate internal interrupt)
                  *******************************************************/

                  /******************************************************
			derive page # ea
			ea is sign-extended but then &= 0x00FFFFFF
                  ******************************************************/

                  v = ea >> 6;

                  if (((v == 0) && ((psr & 0x00800000) == 0))
                  ||  (v >= base[72]))	/*	application threshold	*/
                  {
                     /*********************************************
                        system call ii for applications
                        are not in the restart page
                     *********************************************/

                     GUARD_AUTHORITY;
                  }
                  else ii(ea, 0);
                  return;
               }

               /************************************************

			TZ instruction

			Test Zero and Skip

               ************************************************/

               v = operand_read(ea, designator);
               if (contingency < 0) return;

               if (v & 0x00FFFFFF)
               {
               }
               else apc++;
}

static void tp(int ea, int designator)
{
   int          *_p,
                *_q;

   int           v,
		 w;

               if (designator == I)
               {
                  /******************************************************
                        JDZ instruction
                  *******************************************************/

                  if (((a) | (b)) & 0x00FFFFFF)
                  {
                  }
                  else apc = &b0p->w[ea];
                  return;
               }

               if (designator == XI)
               {
                  /******************************************************
                        IR instruction. return from interrupt
                  *******************************************************/

                  if (psr & 0x00800000)
                  {
                  }
                  else
                  {
                     /***************************************************
                        application issued ir instruction
                        not allowed
                     ***************************************************/

                     GUARD_AUTHORITY
                     return;
                  }

                  STACK_READ(4)
                  _p = _register + v;

                  v += 4;               /* update interrupt stack pointer */
                  *_q = v;		/* immediately in line with	  */
					/* machine code written emulators */

                  /* latent parameter *sp not used on IR */

                  psr = _p[1];
                  b0_name = _p[2];
                  b0_scope = w = b0_name & 0x003FFFFF;
                  b0p = &memory.p4k[w];

                  if (b0_name & 0x00800000)
                  {
                     b0_scope += b0p->w[64].t1 >> 2;
                  }

                  if (b0_scope > (PAGES_IN_MEMORY - 1))
                  {
                     GUARD_INTERRUPT
                     return;
                  }

                  if  (psr & 0x00800000)
                  {
                  }
                  else if (w < base[72])
                  {
                     /****************************************
                        returning PSR is an application
                        must be an ISR to jump in there
                     *****************************************/

                     GUARD_AUTHORITY
                     return;
                  }

                  base[0] = w;

                  #ifdef INSTRUCTION_U	/* update the program counter limit */
                  base[INSTRUCTION_U] = b0_scope;
                  apcz = &memory.p4k[b0_scope].w[4095];
                  #endif

                  w = _p[3];
                  w += ea;
                  w &= 0x00FFFFFF;
                  apc = &b0p->w[w];	/* update the program counter	*/

                  iselect = (psr & 0x00800000) >> 16;

                  return;
               }

               /************************************************

                        Test Positive and Skip

               ************************************************/

               v = operand_read(ea, designator);
               if (contingency < 0) return;

               if (v & 0x00800000)
               {
               }
               else apc++;
}
static void ax(int ea, int designator)
{
               /***********************************************

			add operand to index _register X
                        
                        psr flag CARRY is not changed

               ************************************************/

               int v = x + operand_read(ea, designator);
               if (contingency < 0) return;
               x = v & 0x00FFFFFF;
}

static void ay(int ea, int designator)
{              
               /***********************************************

                        add operand to index _register Y
                        
                        psr flag CARRY is not changed

               ************************************************/

               int v = y + operand_read(ea, designator);
               if (contingency < 0) return; 
               y = v & 0x00FFFFFF;
}

static void or(int ea, int designator)
{
               /*****************************************************

			OR instruction			alu.c

			or accumulator A with the operand value
                        
                        psr flag CARRY is not changed

               *****************************************************/

               __or(ea, designator, &a);
}

static void orB(int ea, int designator)
{
               /****************************************************

			ORB instruction			alu.c

			or accumulator B with the operand value
                        
                        psr flag CARRY is not changed

               ****************************************************/

               __or(ea, designator, &b);
}

static void and(int ea, int designator)
{
               /***************************************************

			AND instruction			alu.c

			and accumulator A with the operand value
                        
                        psr flag CARRY is not changed

               ****************************************************/

               __and(ea, designator, &a);
}

static void andB(int ea, int designator)
{
               /***************************************************

			ANDB instruction		alu.c

			and accumulator B with the operand value
                        
                        psr flag CARRY is not changed

               ****************************************************/

               __and(ea, designator, &b);
}

static void xor(int ea, int designator)
{
               /***************************************************

			XOR instruction			alu.c

			xor accumulator A with the operand value
                        
                        psr flag CARRY is not changed

               ***************************************************/

               __xor(ea, designator, &a);
}

static void xorB(int ea, int designator)
{
               /***************************************************

			XORB instruction		 alu.c

			xor accumulator B with the operand value

			psr flag CARRY is not changed

               ***************************************************/

               __xor(ea, designator, &b);
}

static void aa(int ea, int designator)
{
               /*************************************************

			add to A			alu.c

			add the operand to accumulator A
                        
                        psr flag CARRY is updated

               **************************************************/

               __aa(ea, designator, &a);
}

static void ab(int ea, int designator)
{
               /*************************************************

			add to B			alu.c

			add the operand to accumulator B
                        
                        psr flag CARRY is updated

               *************************************************/

               __aa(ea, designator, &b);
}

static void ana(int ea, int designator)
{
               /***********************************************************

			add negative to A		alu.c

			add the 2s complement of the operand
			to accumulator A, i.e. subtract
                        
                        psr flag CARRY is updated

               ***********************************************************/

               __ana(ea, designator, &a);
}

static void anb(int ea, int designator)
{
               /***********************************************************

			add negative to B		alu.c

			add the 2s complement of the operand
			to accumulator B, i.e. subtract
                        
                        psr flag CARRY is updated

               **********************************************************/

               __ana(ea, designator, &b);
}

static void m(int ea, int designator)
{
               /**********************************************************

			multiply			alu.c

			multiply _register B by the operand
			algebraically, giving a 48-bit product
			in accumulators A:B
                        
                        psr flag CARRY is not changed

               ***********************************************************/

               __m(ea, designator, &a);
}

static void mf(int ea, int designator)
{
               /***********************************************************

			multiply fractional		alu.c

			multiple accumulator B by the operand
			giving a 48-bit product in accumulators A:B

			B is treated as unsigned
			the operand is treated as signed
                        
                        psr flag CARRY is not changed

               ***********************************************************/

               __mf(ea, designator, &a);
}

static void d(int ea, int designator)
{
               /***********************************************************

			divide				alu.c

			divide the 48-bit dividend in accumulators A:B
			by the operand algebraically.

			store the quotient in A and the remainder in B

			quotient high-order bits 47..24 are stored in
			register 6 MANTISSA2 (register 134 in ISR mode)

			psr flag CARRY is not changed

                **********************************************************/

                __d(ea, designator, &a);
}

static void push(int ea, int designator)
{
               /**********************************************************

			place a word on the internal stack

                        acquire operand before decrementing sp
                        in case the pushed object is sp

                        sp at *_q is the same one before and after
                        even if a fault occurs in burst_read

               **********************************************************/

   int          *_p,
                *_q;

   int           v;

               STACK(1)
               v--;
               _p = _register + v;
              *_p = operand_read(ea, designator);
              if (contingency < 0) return;
              *_q = v;
}

void rta()
{
   for (;;)
   {
      execute(*apc++);
   }
}
