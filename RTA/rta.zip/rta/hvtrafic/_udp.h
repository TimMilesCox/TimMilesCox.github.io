typedef struct { unsigned short 	source_p,
					  dest_p,
					   bytes,
					checksum;
		 unsigned char		data[88]; } udgram;

