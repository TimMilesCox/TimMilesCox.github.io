#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "../include.rta/argue.h"
#include "../include.rta/address.h"
#include "../rta.run/settings.h"
#include "../netifx/sifr_mm.h"
#include "_inet.h"
#include "testxref.h"
#include "_assist.h"
#include "config.h"

#define	RTA1_IFIDX	5
void radge(state *transmission);

extern long long	 payload_segments,
			 payload;

static unsigned short check(unsigned int initial, int words, unsigned short *pdu)
{
   unsigned int carry;

   while (words--) initial += *pdu++;
   while ((carry =  (initial >> 16)))
   {
      initial &= 0xFFFF;
      initial += carry;
   }

   return initial ^ 0xFFFF;
}

void icolumn(int what, char *where)
{
   int		used = what % 10000;

   *where++ = used / 1000 | '0'; used %= 1000;
   *where++ = used / 100  | '0'; used %= 100;
   *where++ = used / 10   | '0'; used %= 10;
   *where = used | '0';
}

void rx_callback(state *transmission, datagram *actual, char *data)
{
   unsigned int		 remote_ack,
			 remote_sequence,
			 payload_tx,
			 payload_rx;

   char			*p = (char *) actual;
   int			 iphl = (*p & 15) << 2;		/* IP header LL	*/
   char			*q = p + iphl;			/* tpdu address */
   int			 tphl = (q[12] & 240) >> 2;	/* tcp header L	*/

   char			*local_dgram = (char *) &transmission->dgram;
   int			 local_dgraml = ((*local_dgram) & 15) << 2;
   char			*local_segment = local_dgram + local_dgraml;
   int			 local_tpl = (local_segment[12] & 240) >> 2;
   int			 oh_bytes = local_dgraml + local_tpl;

   segment		*rx_seg = (segment *) q;
   segment		*state_seg = (segment *) local_segment;
   
   payload_rx = PORT((actual->dgram.bytes)) - iphl - tphl;

   if (rx_seg->header.hl_flags & PORT(TCP_RST))
   {
      transmission->state = TCP_DELETETCB;
      return;
   }

   remote_sequence = itranslate(rx_seg->header.sequence);
   remote_ack = itranslate(rx_seg->header.ack);

   if (remote_sequence < transmission->ack)
   {
   }
   else
   {
      if (payload_rx)
      {
         payload_segments++;
         payload += payload_rx;
      }

      transmission->ack = remote_sequence + payload_rx;
   }

   switch (transmission->state)
   {
      case TCP_SYNSENT:
	 printf("[%4.4x %8.8x:%8.8x]\n", PORT(rx_seg->header.hl_flags), transmission->sequence, remote_ack);

         if (((rx_seg->header.hl_flags & TCP_FLAGS) == PORT((TCP_SYN | TCP_ACK)))
         &&  (remote_ack == transmission->sequence))
         {
            remote_sequence++;
            printf("[ A <- %8.8X <- R ]", remote_sequence);
            transmission->ack = remote_sequence;
            state_seg->header.ack = itranslate(remote_sequence);
            state_seg->header.hl_flags = PORT((0x5000 | TCP_ACK));
            transmission->dgram.bytes = PORT(oh_bytes);
            transmission->state = TCP_ESTABLISHED;
            fflush(stdout);
            radge(transmission);

            #ifdef STAGED_VOLUME
            break;
            /* return to start more connections or switch to traffic on command	*/
            #else
            /* and do not break. Get driving traffic				*/
            #endif
         }
         else
         {
            /***********************************************************************
		repeat SYN and stay in SYN_SENT
	    ***********************************************************************/

            radge(transmission);
            break;
         }

      case TCP_ESTABLISHED:

         if (remote_ack < transmission->sequence)
         {
            radge(transmission);
            break;
         }

         if (rx_seg->header.hl_flags & PORT(TCP_FIN))
         {
            state_seg->header.hl_flags = PORT((0x5000 | TCP_ACK | TCP_FIN));
            transmission->ack++;
            state_seg->header.ack = itranslate(transmission->ack);
            transmission->dgram.bytes = PORT(oh_bytes);
	    radge(transmission);
            transmission->sequence++;
            state_seg->header.sequence = itranslate(transmission->sequence);
            transmission->state = TCP_CLOSEWAIT;
            break;
         }

         if (remote_ack == transmission->sequence)
         {
            state_seg->header.sequence = itranslate(transmission->sequence);
            state_seg->header.ack = itranslate(transmission->ack);

            if (transmission->payload_repeat < 0)
            {
               #ifdef STAGED_VOLUME
               /********************************************************************
			ACK to date ans await command more traffic or close
               ********************************************************************/
               transmission->dgram.bytes = PORT(oh_bytes);
               state_seg->header.hl_flags = PORT((0x5000 | TCP_ACK));
               radge(transmission);
               #else
               transmission->dgram.bytes = PORT(oh_bytes);
               state_seg->header.hl_flags = PORT((0x5000 | TCP_ACK | TCP_FIN));
               radge(transmission);
               transmission->sequence++;
               transmission->state = TCP_FINWAIT1;

               /********************************************************************
			sequence is not to be incremented again after here
               ********************************************************************/
               #endif
            }
            else
            {
               state_seg->header.hl_flags = PORT((0x5000 | TCP_ACK | TCP_PSH));
               icolumn(transmission->payload_repeat, (char *) state_seg->data);
               payload_tx = strlen((char *) state_seg->data);

               if (flag['v'-'a']) printf("[ %d -> ]", payload_tx);

               transmission->dgram.bytes = PORT((oh_bytes + payload_tx));
               transmission->payload_repeat--;


               if (remote_sequence ^ transmission->ack)
                  printf("[%x ? %x]\n", remote_sequence, transmission->ack);

               radge(transmission);
               transmission->sequence += payload_tx;
            }
         }
         
         break;

      case TCP_FINWAIT1:

         if (remote_ack < transmission->sequence)
         {
         }
         else 
         {
            if (rx_seg->header.hl_flags & PORT(TCP_ACK))
            {
               state_seg->header.hl_flags = PORT((0x5000 | TCP_ACK));
               state_seg->header.sequence = itranslate(transmission->sequence);
               transmission->state = TCP_FINWAIT2;
            }

            if (rx_seg->header.hl_flags & PORT(TCP_FIN))
            {
               transmission->ack++;
               transmission->state = TCP_CLOSING;
            }

            state_seg->header.hl_flags = PORT((0x5000 | TCP_ACK));
         }

         transmission->dgram.bytes = PORT(40);
         state_seg->header.ack = itranslate(transmission->ack);
         radge(transmission);
         break;

      case TCP_FINWAIT2:
         if (remote_ack < transmission->sequence)
         {
         }
         else 
         {
            if (rx_seg->header.hl_flags & PORT(TCP_ACK))
            {
               state_seg->header.hl_flags = PORT((0x5000 | TCP_ACK));
               state_seg->header.sequence = itranslate(transmission->sequence);
            }

            if (rx_seg->header.hl_flags & PORT(TCP_FIN))
            {
               transmission->ack++;
               state_seg->header.ack = itranslate(transmission->ack);
               transmission->state = TCP_TIMEWAIT;;
            }

            state_seg->header.hl_flags = PORT((0x5000 | TCP_ACK));
         }

         transmission->dgram.bytes = PORT(40);
         state_seg->header.ack = itranslate(transmission->ack);
         radge(transmission);
         break;
                  
      case TCP_CLOSING:
         if (remote_ack < transmission->sequence)
         {
            radge(transmission);
         }
         else
         {  
            if (rx_seg->header.hl_flags & PORT(TCP_ACK))
            {  
               transmission->state = TCP_TIMEWAIT;
            }
         }

         break;

      case TCP_TIMEWAIT:
         transmission->state = TCP_CLOSED;
         break;

      case TCP_CLOSEWAIT:
      case TCP_LASTACK:
         if (remote_ack < transmission->sequence)
         {
            radge(transmission);
         }
         else
         {
            if (rx_seg->header.hl_flags & PORT(TCP_ACK))
            {
               transmission->state = TCP_CLOSED;
            }
         }

         break;

      case TCP_CLOSED:
         transmission->state = TCP_LISTEN;
         break;

      default:
         break;
   }

   if (flag['v'-'a']) printf("[%x]\n", transmission->state);
}

void radge(state *traffic)
{
   char *p = (char *) &traffic->dgram;
   int bytes = PORT(traffic->dgram.bytes);
   int ipbytes = ((*p) & 15) << 2;
   int tpdul = bytes - ipbytes;
   int tpduw = (tpdul + 1) >> 1;
   int checksum;
   int triangle = 1;
   int window = 8192;	/* (int) (limit_o - threshold_o) * 80 / established; */

   char *q = p + ipbytes;
   segment *tseg = (segment *) q;



   if (tpdul & 1) *(q + tpdul) = 0;

   if (flag['v'-'a']) printf("send[%d:%d]\n", (int) (rxdata - threshold_o), window);

   if (window > 65535) window = 65535;
   tseg->header.window = PORT(window);
   tseg->header.checksum = 0;

   checksum = check(PORT((tpdul + 6))
            + traffic->dgram.source_net.low + traffic->dgram.source_net.high
            + traffic->dgram.dest_net.low + traffic->dgram.dest_net.high,
	tpduw, (unsigned short *) tseg);

   tseg->header.checksum = checksum;
   bytes += LL_HL;
   traffic->dgram.checksum = 0;
   traffic->dgram.checksum = check(0, ipbytes >> 1, (unsigned short *) &traffic->dgram);

   #ifdef LINUX
   traffic->frame.w[6] = IP;
   #endif

   #ifdef OSX
   traffic->frame.pfamily = AF_INET;
   #endif

   #if 1

   /*******************************************************************
	if you can't you don't
	it's lost between departure and arrival
	up to the state machine this end to try again
	and it doesn't change state without a response
   *******************************************************************/


   if (uflag['S'-'A']) usleep(NET_GRANULE * 2);

   if (rxdata->preamble.flag)
   {
      if (uflag['L'-'A'])
      {
         putchar('|');
         fflush(stdout);
      }

      return;
   }

   #else

   while (rxdata->preamble.flag)
   {
      usleep(triangle);
      if (rxdata->preamble.flag == 0) break;
      triangle <<= 1;
      if (triangle ^ 0x00020000) continue;
      putchar('*');
      fflush(stdout);
      return;
   }

   #endif

   #if 1

   /*****************************************************************
	playing directly into RTA1 address space
	on RX that is datagram only
   *****************************************************************/

   memcpy(rxdata->frame, &traffic->dgram, bytes);

   #else

   memcpy(rxdata->frame, &traffic->frame, bytes);

   #endif

   rxdata->preamble.frame_length = PORT(bytes);
   rxdata->preamble.i_f = PORT(RTA1_IFIDX);
   rxdata->preamble.protocol = IP;
   rxdata->preamble.flag = PORT(32768);

   if (flag['g'-'a'])
   {
      printf("[UX %p %4.4x:%4.4x:%4.4x:%4.4x:%4.4x]\n[", rxdata,
              PORT(rxdata->preamble.flag),
              PORT(rxdata->preamble.frame_length), PORT(rxdata->preamble.ll_hl),
              PORT(rxdata->preamble.i_f),          PORT(rxdata->preamble.protocol));

      p = (char *) rxdata->frame;

      #if 1
      q = p;
      #else
      q = p + LL_HL;
      #endif

      while (p < q) printf("%2.2x", *p++);
      printf("]\n");

      formout((bytes + 19 - LL_HL) / 20,  q);
   }

   if (flag['v'-'a']) printf("%p %p %p %x\n", threshold_i, threshold_o, rxdata, rxdata->preamble.flag);

   if (uflag['V'-'A']) printf("%p -> ", rxdata);
   rxdata++;

   if (rxdata < threshold_o)
   {
   }
   else rxdata = threshold_i;
   if (uflag['V'-'A']) printf("%p\n", rxdata);

   if (flag['v'-'a']) printf("x_send\n");
}

