#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "../include.rta/argue.h"
#include "../include.rta/address.h"
#include "../netifx/sifr_mm.h"
#include "_inet.h"
#include "tcp_part.h"
#include "_assist.h"
#include "testxref.h"
#include "config.h"

#define MAXIMUM_PORTS	256
#define	MAXIMUM_WIDTH	4096

#define	MSS	(2048-10-14-20-20)

#define	SOURCE_PORT_RESTART 1024
#define REQUEST	72

#ifdef	INTEL
static net_address source_net = { 0x010A, 0x0100 } ;
static net_address dest_net   = { 0x000A, 0x0a00 } ;

#define	LOCAL_NET_RESTART 0x0100

#else
static net_address source_net = { 0x0A01, 0x0001 } ;
static net_address dest_net   = { 0x0A00, 0x000a } ;

#define	LOCAL_NET_RESTART 0x0001

#endif

#define START_SEQUENCE 0x3F000000


static state demand[MAXIMUM_PORTS * MAXIMUM_WIDTH];

static int			 remote_start_port,
				 connections_pro;

int                              established;

extern int			 tpexit;

static char			*category[] = { "zero", 
						"closed",
						"listen",
						"synsent",
						"synreceived",
						"established",
						"finwait1",
						"finwait2",
						"closewait",
						"lastack",
						"closing",
						"timewait",
						"deletetcb",
						"out of range" } ;

extern long long		 payload_segments,
				 payload;
extern void restart(void);
extern void icolumn(int what, unsigned char *where);

void callback(unsigned char *dgram)
{
   datagram		*actual = (datagram *) dgram;
   state		*transmission;

   unsigned int		 remote_sequence,
			 remote_ack,
			 payload_rx,
			 payload_tx;

   int			 remote_host_index = dgram[18] | ((dgram[19] - 1) << 8);

   int			 bytes = (dgram[2] << 8) | dgram[3];
   int			 ip_hlen = (dgram[0] & 15) << 2;
   unsigned char	*tpdu = dgram + ip_hlen;
   int			 tp_hlen = (tpdu[12] & 240) >> 2;
   unsigned char	*payload = tpdu + tp_hlen;

   segment		*tseg = (segment *) tpdu;
   int			 tsource_p = PORT(tseg->header.source_p);
   int			 tdest_p   = PORT(tseg->header.dest_p);
   int			 index = (tsource_p - remote_start_port) * connections_pro
                               + remote_host_index;

   if (flag['v'-'a'])
   {
       if (uflag['V'-'A']) printf("[%2.2x %2.2x %2.2x %2.2x]", dgram[0], dgram[1], dgram[2], dgram[3]);
       printf("[RX]\n");
       formout(4, (char *) dgram);

       printf("(%d - %d) * %d + %4.4x = %d\n",
               tsource_p, remote_start_port, connections_pro, remote_host_index, index);
   }

   if (flag['t'-'a'])
   {
      printf ("%d.%d.%d.%d:%d <- %2.2x%2.2x:%2.2x%2.2x%2.2x%2.2x",
              dgram[16], dgram[17], dgram[18], dgram[19], tdest_p, 
              tpdu[12], tpdu[13],
	      tpdu[8],  tpdu[9], tpdu[10], tpdu[11]);

      if (bytes > (ip_hlen + tp_hlen))
      {
         dgram[bytes] = 0;
         printf("\n%s", payload);
      }

      printf("\n");
   }
   
   transmission = demand + index;

   if (flag['w'-'a']) formout(4, (char *) (unsigned char *) transmission);
   if (flag['v'-'a']) printf("[%p: %x]", transmission, (int) sizeof(state));
   rx_callback(transmission, actual, tseg->data);
}

static void burst(int port, int ports, int connections, int times, char *text)
{
   int			 x = times,
			 y = ports,
			 width = connections,
			 dest_p = port,
			 source_p = SOURCE_PORT_RESTART;

   state		*traffic = demand + established;
   int			 window = 8192;	/*(262144 - 260 * 2 - 48 * connections - 16) / connections; */

   unsigned char	*p;
   segment		*tseg;

   established += connections; 

   if (window > 65535) window = 65535;
   connections_pro = width;

   while (y--)
   {
//      source_net.low = LOCAL_NET_RESTART;
//      remote_start_port = source_p;

      while (width--)
      {
	 p = (unsigned char *) &traffic->dgram;
	 p += 20;
	 tseg = (segment *) p;

         traffic->sequence = START_SEQUENCE;
	 traffic->ack = 0;

         tseg->header.source_p = PORT(source_p);
         tseg->header.dest_p = PORT(dest_p);
         tseg->header.sequence = itranslate(traffic->sequence);
         tseg->header.ack = 0;
	 tseg->header.hl_flags = PORT((0x6000 | TCP_SYN));
	 tseg->header.window = PORT(window);
	 tseg->header.urgent_p = 0;
         tseg->data[0] = 2;
	 tseg->data[1] = 4;
         tseg->data[2] = MSS >> 8;
         tseg->data[3] = MSS & 255;
         tseg->data[4] = ' ';

         #ifdef LINUX
	 strncpy((char *) traffic->tpdu.tcp.data + 5, text, 71);
         #endif

         #ifdef OSX
	 strlcpy((char *) traffic->tpdu.tcp.data + 5, text, 71);
         #endif

         traffic->dgram.hl_tos = IPV4_TOS;
         traffic->dgram.bytes = PORT(44);
	 traffic->dgram.dnf_frag = DNF_FRAG;
	 traffic->dgram.ttl_uproto = TTL_TCP;
	 traffic->dgram.dest_net = dest_net;
	 traffic->dgram.source_net = source_net;

	 radge(traffic);

         if (uflag['V'-'A'])
         {
            p = (unsigned char *) &traffic->dgram;
            x = 48;
            while (x--) printf("%2.2x", *p++);
            putchar(10);
         }

         traffic->sequence++;
	 tseg->header.sequence = itranslate(traffic->sequence);
	 traffic->state = TCP_SYNSENT;

	 traffic->payload_repeat = times;
	 source_net.low++;
         traffic++;
      }

      dest_p++;
      source_p++;
   }
}

#ifdef	STAGED_VOLUME
static void straffic(int connection, int connections, int times, char *text)
{
   state                *traffic = demand + connection;
   int                   window = 8192;	/* (262144 - 260 * 2 - 48 * connections - 16) / connections; */
 
   char			*p,
			*q;

   int			 ip_hlen,
			 tp_hlen,
			 bytes;
 
   segment		*tseg = (segment *) q;

 
   if (window > 65535) window = 65535;

   while (connections--)
   {
      traffic->payload_repeat = times;

      p = (char *) &traffic->dgram;
      ip_hlen = (*p & 15) << 2;
      q = p + ip_hlen;
      tseg = (segment *) q;
      tp_hlen = (*(q + 12) & 240) >> 2;
      bytes = ip_hlen + tp_hlen + 5;

      #ifdef LINUX
      bytes += strlen(text);
      strncpy((char *) tseg->data + 5, text, 71);
      #endif

      #ifdef OSX
      bytes += strlcpy((char *) tseg->data + 5, text, 71);
      #endif

      traffic->dgram.bytes = PORT(bytes);
      if (times < 1) times = 1;
      icolumn(times, tseg->data);
      traffic->payload_repeat = times - 1;
      radge(traffic);
      traffic++;
   }
}

static void sclose(int connection, int connections)
{
   state                *traffic = demand + connection;
   int                   window = 8192; /* (262144 - 260 * 2 - 48 * connections - 16) / connections; */

   char			*p,
			*q;

   int			 ip_hlen,
			 bytes;

   segment		*tseg;

   if (window > 65535) window = 65535;

   while (connections--)
   {
      p = (char *) &traffic->dgram;
      ip_hlen = (*p & 15) << 2;
      q = p + ip_hlen;
      tseg = (segment *) q;
      bytes = ip_hlen + 20;

      traffic->dgram.bytes = PORT(bytes);
      traffic->tpdu.tcp.header.hl_flags = PORT((0x5000 | TCP_FIN | TCP_ACK));
      radge(traffic);
      traffic->sequence++;
      traffic->state = TCP_FINWAIT1;
      traffic++;
   }
}
#endif

static void free_connections(int connections)
{
   state	*to = demand;

   char		*p,
		*q;

   int		 ip_hlen,
                 bytes;

   segment	*tseg;

   while (connections--)
   {
      p = (char *) &to->dgram;
      ip_hlen = ((*p) & 15) << 2;
      q = p + ip_hlen;
      bytes = ip_hlen + 20;
      tseg = (segment *) q;

      tseg->header.hl_flags = PORT((0x5000 | TCP_RST));
      to->dgram.bytes = PORT(bytes);
      radge(to);
   }
}

void procedure(void)
{
   char			 request[REQUEST];
   char			 text2u[REQUEST];

   char			*p;

   int			 offset,
			 port,
			 ports,
			 times;

   state		*q;

   int			 x,
			 y;

   int			 triangle;

   int			 slab,
			 cursor;

   unsigned char	*qq;


   struct { unsigned		 bucket[14]; } tcb_states;

   printf("test procedure %p %p\n", threshold_i, rxdata);

   #ifdef STAGED_VOLUME
   source_net.low = LOCAL_NET_RESTART;
//   remote_start_port = SOURCE_PORT_RESTART;
   #endif

   for (;;)
   {
      printf("to_port/ports/connections_port, repeat, text>");
      fflush(stdout);
      memset(request, 0, REQUEST);
      p = fgets(request, REQUEST, stdin);
      if (p == NULL) break;
      if (*p == '.') break;

      if (*p == '-')
      {
         reflag(p);
         continue;
      }

      if (*p == 'r')
      {
         restart();
         continue;
      }

      if (*p == 'f')
      {
         x = established;
         sscanf(p + 1, "%d", &x);
         free_connections(x);
         continue;
      }

      if (*p == '^')
      {
         established = 0;
         continue;
      }

      if (*p == '*')
      {
         /*************************************************
		rx pointer -> 1st region of space
	 *************************************************/

         cursor = (int) (rxdata - threshold_i);
         slab = cursor >> 8;
         printf("RX %x:%6.6x\n", slab, (cursor & 255) << 10);

         /*************************************************
                tx pointer -> 2nd region of space
         *************************************************/

         cursor = (int) (txdata - threshold_i);
         slab = cursor >> 8;
         printf("TX %x:%6.6x\n", slab, (cursor & 255) << 10);
         continue;
      }

      if (*p == '?')
      {
         for (x = 0; x < 14; x++) tcb_states.bucket[x] = 0;

         y = established;
	 sscanf(request + 1, "%d", &y);
         q = demand;

         while (y--)
         {
            x = q->state;
            if (x > 13) x = 13;
            tcb_states.bucket[x]++;
            q++;
         }

         for (x = 0; x < 14; x++)
         {
            if (tcb_states.bucket[x]) printf("%d %s\n", tcb_states.bucket[x], category[x]);
         }

         if (payload_segments)
         {
            printf("payload segments %lld payload %lld\n", payload_segments, payload);
         }

         continue;
      }

      #ifdef STAGED_VOLUME
      if (*p == '=')
      {
         /******************************************************************************
		fire some data
         ******************************************************************************/

         sscanf(request + 1, "%d/%d,%d,%s", &offset, &connections_pro, &times, text2u);
         straffic(offset, connections_pro, times, text2u);
      }

      if (*p == '<')
      {  
         /******************************************************************************
                close some connections
         ******************************************************************************/
         
         sscanf(request + 1, "%d/%d", &offset, &connections_pro);
         sclose(offset, connections_pro);
      }
      #endif

      /*********************************************************************************
		construct connections
      *********************************************************************************/

      if (*p == '+')
      {
         sscanf(request + 1, "%d/%d/%d,%d,%s", &port, &ports, &connections_pro, &times, text2u);
         burst(port, ports, connections_pro, times, text2u);
         remote_start_port = port;
      }

      if ((*p == '+') || (*p == '>') || (*p == '<'))
      {
         for (;;)
         {
            if (txdata->preamble.flag)
            {
	       if (uflag['V'-'A']) 
	       {
		  x = sizeof(frame_head);
		  qq = (unsigned char*) txdata->frame;
		  while (x--) printf("%2.2x:", *qq++);
	       }

               callback((unsigned char *) txdata->frame + sizeof(frame_head));
               txdata->preamble.flag = 0;
               txdata++;

               if (txdata < limit_o)
               {
               }
               else txdata = threshold_o;
            }
            else
            {
               /****************************************************
               if responses pause
               back of gradually until it's a fair assumption
               because you have to stop the test sometime
	       and look how far it got
               ****************************************************/

               triangle = 1;

               while (triangle ^ 0x00400000)
               {
                  usleep(triangle);
                  if (txdata->preamble.flag) break;
                  triangle <<= 1;
               }
               if (txdata->preamble.flag) continue;
               break;
            }
         }
      }
   }

   printf("end test procedure\n");
   tpexit = -1;
}

