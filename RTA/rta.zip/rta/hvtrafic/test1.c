#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "../include.rta/argue.h"
#include "../include.rta/address.h"
#include "../netifx/sifr_mm.h"
#include "_inet.h"
#include "tcp_part.h"
#include "_assist.h"
#include "testxref.h"

#define MAXIMUM_PORTS	256
#define	MAXIMUM_WIDTH	4096

#define	MSS	(2048-10-14-20-20)

#define	SOURCE_PORT_RESTART 10240
#define REQUEST	72

#ifdef	INTEL
static net_address source_net = { 0x010A, 0x0100 } ;
static net_address dest_net   = { 0x000A, 0x0a00 } ;

#define	LOCAL_NET_RESTART 0x0100

#else
static net_address source_net = { 0x0A01, 0x0001 } ;
static net_address dest_net   = { 0x0A00, 0x000a } ;

#define	LOCAL_NET_RESTART 0x0001

#endif

#define START_SEQUENCE 0x3F000000


static state demand[MAXIMUM_PORTS * MAXIMUM_WIDTH];

static int			 remote_start_port,
				 connections_pro;

extern int			 tpexit;

static char			*category[] = { "zero", 
						"closed",
						"listen",
						"synsent",
						"synreceived",
						"established",
						"finwait1",
						"finwait2",
						"closewait",
						"lastack",
						"closing",
						"timewait",
						"deletetcb",
						"out of range" } ;


extern void restart(void);

void callback(char *dgram)
{
   datagram	*actual = (datagram *) dgram;
   state	*transmission;

   unsigned int	 remote_sequence,
		 remote_ack,
		 payload_rx,
		 payload_tx;

   int		 remote_host_index = dgram[18] | ((dgram[19] - 1) << 8);

   int		 tsource_p = PORT(actual->tpdu.tcp.header.source_p);
   int		 tdest_p = PORT(actual->tpdu.tcp.header.dest_p);

   int		 index = (tsource_p - remote_start_port) * connections_pro
               	       + remote_host_index;

   int		 bytes = (dgram[2] << 8) | dgram[3];
   int		 ip_hlen = (dgram[0] & 15) << 2;
   char		*tpdu = dgram + ip_hlen;
   int		 tp_hlen = (tpdu[12] & 240) >> 2;
   char		*payload = tpdu + tp_hlen;

   if (flag['v'-'a'])
   {
       printf("[RX]\n");
       formout(4, (char *) dgram);

       printf("(%d - %d) * %d + %4.4x = %d\n",
               tsource_p, remote_start_port, connections_pro, remote_host_index, index);
   }

   if (flag['t'-'a'])
   {
      printf ("%d.%d.%d.%d:%d <- %2.2x%2.2x",
              dgram[16], dgram[17], dgram[18], dgram[19], tdest_p, 
              tpdu[12], tpdu[13]);

      if (bytes > (ip_hlen + tp_hlen))
      {
         dgram[bytes] = 0;
         printf("\n%s", payload);
      }

      printf("\n");
   }
   
   transmission = demand + index;

   if (flag['w'-'a']) formout(4, (char *) (unsigned char *) transmission);
   if (flag['v'-'a']) printf("[%p: %x]", transmission, (int) sizeof(state));
   rx_callback(transmission, actual, actual->tpdu.tcp.data);
}

static void burst(int port, int ports, int connections, int times, char *text)
{
   int			 x = times,
			 y = ports,
			 width = connections,
			 dest_p = port,
			 source_p = SOURCE_PORT_RESTART;

   state		*traffic = demand;
   int			 window = (262144 - 260 * 2 - 48 * connections - 16) / connections;
 
  if (window > 65535) window = 65535;
  connections_pro = width;

   while (y--)
   {
      source_net.low = LOCAL_NET_RESTART;
      remote_start_port = source_p;

      while (width--)
      {
         traffic->sequence = START_SEQUENCE;
	 traffic->ack = 0;

         traffic->tpdu.tcp.header.source_p = PORT(source_p);
         traffic->tpdu.tcp.header.dest_p = PORT(dest_p);
         traffic->tpdu.tcp.header.sequence = itranslate(traffic->sequence);
         traffic->tpdu.tcp.header.ack = 0;
	 traffic->tpdu.tcp.header.hl_flags = PORT((0x6000 | TCP_SYN));
	 traffic->tpdu.tcp.header.window = PORT(window);
	 traffic->tpdu.tcp.header.urgent_p = 0;
         traffic->tpdu.tcp.data[0] = 2;
	 traffic->tpdu.tcp.data[1] = 4;
         traffic->tpdu.tcp.data[2] = MSS >> 8;
         traffic->tpdu.tcp.data[3] = MSS & 255;
         traffic->tpdu.tcp.data[4] = ' ';
         strlcpy((char *) traffic->tpdu.tcp.data + 5, text, 71);

         traffic->dgram.hl_tos = IPV4_TOS;
         traffic->dgram.bytes = PORT(44);
	 traffic->dgram.dnf_frag = DNF_FRAG;
	 traffic->dgram.ttl_uproto = TTL_TCP;
	 traffic->dgram.dest_net = dest_net;
	 traffic->dgram.source_net = source_net;

	 radge(traffic);
         traffic->sequence++;
	 traffic->tpdu.tcp.header.sequence = itranslate(traffic->sequence);
	 traffic->state = TCP_SYNSENT;

	 traffic->payload_repeat = times;

	 source_net.low++;
         traffic++;
      }

      dest_p++;
      source_p++;
   }
}

static void free(int connections)
{
   state	*to = demand;

   while (connections--)
   {
      to->tpdu.tcp.header.hl_flags = PORT((0x5000 | TCP_RST));
      to->dgram.bytes = PORT(40);
      radge(to);
   }
}

void procedure(void)
{
   char			 request[REQUEST];
   char			 text2u[REQUEST];

   char			*p;

   int			 port,
			 ports,
			 times;

   state		*q;

   int			 x,
			 y;

   int			 triangle;


   struct { unsigned		 bucket[14]; } tcb_states;

   printf("test procedure %p %p\n", threshold_i, rxdata);

   for (;;)
   {
      printf("to_port/ports/connections_port, repeat, text>");
      fflush(stdout);
      memset(request, 0, REQUEST);
      p = fgets(request, REQUEST, stdin);
      if (p == NULL) break;
      if (*p == '.') break;

      if (*p == '-')
      {
         reflag(p);
         continue;
      }

      if (*p == 'r')
      {
         restart();
         continue;
      }

      if (*p == 'f')
      {
         x = connections_pro;
         sscanf(p + 1, "%d", &x);
         free(x);
         continue;
      }

      if (*p == '?')
      {
         for (x = 0; x < 14; x++) tcb_states.bucket[x] = 0;

         y = ports * connections_pro;
         q = demand;

         while (y--)
         {
            x = q->state;
            if (x > 13) x = 13;
            tcb_states.bucket[x]++;
            q++;
         }

         for (x = 0; x < 14; x++)
         {
            if (tcb_states.bucket[x]) printf("%d %s\n", tcb_states.bucket[x], category[x]);
         }
         continue;
      }

      sscanf(request, "%d/%d/%d,%d,%s", &port, &ports, &connections_pro, &times, text2u);
      burst(port, ports, connections_pro, times, text2u);

      for (;;)
      {
         if (txdata->preamble.flag)
         {
            callback((char *) txdata->frame + sizeof(frame_head));
            txdata->preamble.flag = 0;
            txdata++;

            if (txdata < limit_o)
            {
            }
            else txdata = threshold_o;
         }
         else
         {
            /****************************************************
               if responses pause
               back of gradually until it'a a fair assumption
               because you have to stop the test sometime
	       and look how far it got
            ****************************************************/

            triangle = 1;

            while (triangle ^ 0x01000000)
            {
               usleep(triangle);
               if (txdata->preamble.flag) break;
               triangle <<= 1;
            }
            if (txdata->preamble.flag) continue;
            break;
         }
      }
   }

   printf("end test procedure\n");
   tpexit = -1;
}

