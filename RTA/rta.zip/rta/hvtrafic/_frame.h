typedef struct { datagram_start		   dgram;
		 union { udgram	 udp;
			 segment tcp; }	    tpdu; } datagram;

typedef struct { frame_head		 frame_h;
		 datagram_start		   dgram;
		 union { udgram	 udp;
			 segment tcp; }     tpdu; } frame;

