   if (flag['v'-'a'])
   {
       printf("[RX]\n");
       formout(4, dgram);

       printf("(%d - %d) * %d + %d - %d = %d\n",
               tsource_p, remote_start_port, connections_pro, tdest_p, SOURCE_PORT_RESTART, index);
   }
   
   switch (transmission->state)
   {
      case TCP_ESTABLISHED:
         if (actual->tpdu.tcp.header.hl_flags & TCP_RST)
         {
            transmission->state = TCP_DELETETCB;
            break;
         }

         if (actual->tpdu.tcp.header.hl_flags & TCP_FIN)
         {
            transmission->tpdu.tcp.header.hl_flags = PORT(0x5000 | TCP_ACK | TCP_FIN);
            transmission->ack++;
            transmission->tpdu.tcp.header.ack = itranslate(transmission->ack);
            transmission->dgram.bytes = PORT(40);
	    radge(transmission);
            transmission->sequence++;
            transmission->tpdu.tcp.header.sequence = itranslate(transmission->sequence);
            transmission->state = TCP_LASTACK;
            break;
         }

         remote_ack = itranslate(actual->tpdu.tcp.header.ack);

         if (remote_ack == transmission->sequence)
         {
            if (transmission->payload_repeat < 0)
            {
               transmission->dgram.bytes = PORT(40);
               transmission->tpdu.tcp.header.hl_flags = PORT(05000 | TCP_FIN);
               radge(transmission);
               transmission->sequence++;
               transmission->tpdu.tcp.header.sequence = transmission->sequence;
               transmission->state = TCP_FINWAIT1;
            }
            else
            {
               payload_tx = sprintf(transmission->tpdu.tcp.data, "%d %s",
                                            transmission->payload_repeat,
                                                                  rxtext);

               transmission->dgram.bytes = PORT((40 + payload_tx));
               transmission->payload_repeat--;

               remote_sequence = itranslate(actual->tpdu.tcp.header.sequence);
               payload_rx = PORT(actual->dgram.bytes) - 40;

               if (remote_sequence ^ transmission->ack)
                  printf("[%x ? %x]\n", remote_sequence, transmission->ack);
	       transmission->ack = remote_sequence;
               transmission->tpdu.tcp.header.ack = itranslate(transmission->ack + payload_rx);

               radge(transmission);
               transmission->sequence += payload_tx;
               transmission->tpdu.tcp.header.sequence = itranslate(transmission->sequence);
            }
         }
         else radge(transmission);
         
         break;

      case TCP_SYNSENT:

         if ((actual->tpdu.tcp.header.hl_flags & 0x0FFF) == (TCP_SYN | TCP_ACK))
         {  
            remote_sequence = itranslate(actual->tpdu.tcp.header.sequence);
            remote_sequence++;
            transmission->tpdu.tcp.header.ack = itranslate(remote_sequence);
            transmission->tpdu.tcp.header.hl_flags = PORT(0x5000 | TCP_ACK);
            transmission->dgram.bytes = PORT(40);
            transmission->state = TCP_ESTABLISHED;
         }

         radge(transmission);
         break;

      case TCP_FINWAIT1:
	 if (actual->tpdu.tcp.header.hl_flags & TCP_FIN)
         {
            transmission->ack++;
            transmission->tpdu.tcp.header.ack = itranslate(transmission->ack);
            transmission->state = TCP_FINWAIT2;
         }

         transmission->dgram.bytes = PORT(40);
         radge(transmission);
         break;

      default:
         transmission->state = TCP_LISTEN;

   }
}

