
#ifdef INTEL
extern int itranslate(int from);
#else
#define itranslate(X) X
#endif

extern void formout(int lines, char *q);
