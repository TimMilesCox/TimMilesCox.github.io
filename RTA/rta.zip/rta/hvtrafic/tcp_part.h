extern void rx_callback(state *transmission, datagram *actual, unsigned char *data);
extern void radge(state *traffic);

