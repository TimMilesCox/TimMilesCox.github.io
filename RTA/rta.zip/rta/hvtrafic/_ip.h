#define	IPV4_TOS	PORT(0x4500)
#define	DNF_FRAG	PORT(0x4000)
#define	TTL_TCP		PORT(0x3C06)

typedef struct { unsigned short		    high,
					     low; } net_address;

typedef struct { unsigned short		  hl_tos,
		 			   bytes,
					      id,
					dnf_frag,
				      ttl_uproto,
					checksum;
		net_address	      source_net,
					dest_net; } datagram_start;
				
