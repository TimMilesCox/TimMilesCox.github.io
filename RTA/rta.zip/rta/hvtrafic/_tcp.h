#define	TCP_URG		32
#define	TCP_ACK		16
#define	TCP_PSH		8
#define	TCP_RST		4
#define	TCP_SYN		2
#define	TCP_FIN		1

#define	TCP_FLAGS	PORT(0x0FFF)

#define	TCP_CLOSED	1
#define	TCP_LISTEN	2
#define	TCP_SYNSENT	3
#define	TCP_SYNRECEIVED	4
#define	TCP_ESTABLISHED	5
#define	TCP_FINWAIT1	6
#define	TCP_FINWAIT2	7
#define	TCP_CLOSEWAIT	8
#define	TCP_LASTACK	9
#define	TCP_CLOSING	10
#define	TCP_TIMEWAIT	11
#define	TCP_DELETETCB	12

typedef struct { unsigned short		source_p,
					  dest_p;
		 unsigned int		sequence,
					     ack;
		 unsigned short		hl_flags,
					  window,
					checksum,
					urgent_p; } segment_start;

typedef struct { segment_start		  header;
		 unsigned char		data[76]; } segment;

