#ifdef	LINUX
#define	LL_HL	14
typedef struct { unsigned short		    w[7]; } frame_head;
#endif

#ifdef	OSX
#define	AF_INET	2
#define	LL_HL	4
typedef struct { unsigned int	 	 pfamily; } frame_head;
#endif

