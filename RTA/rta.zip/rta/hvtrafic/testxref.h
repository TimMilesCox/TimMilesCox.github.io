extern mm_netbuffer             *dpointer,
                                *threshold_i,
                                *threshold_o,
                                *limit_o;

extern mm_netbuffer             *rxdata,
                                *txdata;

extern int			 established;

// extern unsigned short check(unsigned int initial, int words, unsigned short *pdu);

