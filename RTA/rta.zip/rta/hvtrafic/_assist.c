#include <stdio.h>

#ifdef  INTEL
int itranslate(unsigned int from)
{
   return (from >> 24)
       | ((from >> 8) & 0xFF00)
       | ((from & 0xFF00) << 8)
       |  (from << 24);
}
#endif

void formout(int lines, char *q)
{
   int		 x;

   while (lines--)
   {
      x = 20;
      while (x--) printf("%2.2x", *q++);
      putchar('\n');
   }	
}

