typedef struct { int			   state;
		 unsigned int		sequence,
		                            ack;
		 int		  payload_repeat;
		 frame_head		   frame;
		 datagram_start		   dgram;
		 union { udgram  udp;
			 segment tcp; }	    tpdu; } state;


