   if (flag['v'-'a'])
   {
       printf("[RX]\n");
       formout(4, dgram);

       printf("(%d - %d) * %d + %d - %d = %d\n",
               tsource_p, remote_start_port, connections_pro, tdest_p, SOURCE_PORT_RESTART, index);
   }
   
