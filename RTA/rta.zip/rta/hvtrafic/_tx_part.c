static void radge(state *traffic)
{
   int bytes = PORT(traffic->dgram.bytes);
   int ipbytes = (PORT(traffic->dgram.hl_tos) >> 6) & 60;
   int tpdul = bytes - ipbytes;
   int tpduw = (tpdul + 1) >> 1;
   int checksum;

   if (tpdul & 1) *(((char *) &traffic->tpdu) + tpdul) = 0;

   if (flag['v'-'a']) printf("send\n");

   traffic->tpdu.tcp.header.checksum = 0;

   checksum = check(PORT((tpdul + 6))
            + traffic->dgram.source_net.low + traffic->dgram.source_net.high
            + traffic->dgram.dest_net.low + traffic->dgram.dest_net.high,
	tpduw, (unsigned short *) &traffic->tpdu);

   traffic->tpdu.tcp.header.checksum = PORT(checksum);
   bytes += LL_HL;
   traffic->dgram.checksum = 0;
   traffic->dgram.checksum = check(0, 10, (unsigned short *) &traffic->dgram);
   traffic->frame.pfamily = AF_INET;

   while (rxp->preamble.flag) usleep(1000);
   memcpy(rxp->frame, &traffic->frame, bytes);
   rxp->preamble.frame_length = PORT(bytes);
   rxp->preamble.i_f = 0;
   rxp->preamble.protocol = IP;
   rxp->preamble.flag = PORT(32768);

   if (flag['v'-'a']) printf("%p %p %p %x\n", threshold_i, threshold_o, rxp, rxp->preamble.flag);

   rxp++;
   if (rxp < threshold_o)
   {
   }
   else rxp = threshold_i;

   if (flag['v'-'a']) printf("x_send\n");
}

static void formout(int lines, char *q)
{
   int		 x;

   while (lines--)
   {
      x = 20;
      while (x--) printf("%2.2x", *q++);
      putchar('\n');
   }	
}

