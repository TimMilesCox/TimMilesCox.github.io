
#define HOSTS   	6
#define	ADDRESS_STRING	160
#define	REVISION1

unsigned char *peel(unsigned char *to, unsigned char *from);
int portal(int iftype, unsigned char *ifname, unsigned char *addresses);

