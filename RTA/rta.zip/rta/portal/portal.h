int portal(int iftype, unsigned char *ifname, unsigned char *addresses);

